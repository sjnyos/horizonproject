﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class OldFrontDesk
    Inherits MetroFramework.Forms.MetroForm







    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.SETUPToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ENTRIESToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.REPORTSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EDITCHANGESToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LOGSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HELPToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RoomOrderToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ResturantOrderToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ResturrantEntryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OtherChangesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BillOnHoldToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PanelLeft = New System.Windows.Forms.Panel()
        Me.PanelRight = New System.Windows.Forms.Panel()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.MaterialFlatButton10 = New MaterialSkin.Controls.MaterialFlatButton()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.MaterialFlatButton9 = New MaterialSkin.Controls.MaterialFlatButton()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.MaterialFlatButton8 = New MaterialSkin.Controls.MaterialFlatButton()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.MaterialFlatButton7 = New MaterialSkin.Controls.MaterialFlatButton()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.MaterialFlatButton6 = New MaterialSkin.Controls.MaterialFlatButton()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.MaterialFlatButton5 = New MaterialSkin.Controls.MaterialFlatButton()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.MaterialFlatButton4 = New MaterialSkin.Controls.MaterialFlatButton()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.MaterialFlatButton3 = New MaterialSkin.Controls.MaterialFlatButton()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.MaterialFlatButton2 = New MaterialSkin.Controls.MaterialFlatButton()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.MaterialFlatButton1 = New MaterialSkin.Controls.MaterialFlatButton()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.MenuStrip2 = New System.Windows.Forms.MenuStrip()
        Me.SETUToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EntriesToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.REPORTSToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.EDITCHANGESToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.LOGSToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        Me.PanelRight.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        Me.MenuStrip2.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SETUPToolStripMenuItem, Me.ENTRIESToolStripMenuItem, Me.REPORTSToolStripMenuItem, Me.EDITCHANGESToolStripMenuItem, Me.LOGSToolStripMenuItem, Me.HELPToolStripMenuItem, Me.RoomOrderToolStripMenuItem, Me.ResturantOrderToolStripMenuItem, Me.ResturrantEntryToolStripMenuItem, Me.OtherChangesToolStripMenuItem, Me.BillOnHoldToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(20, 84)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1232, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'SETUPToolStripMenuItem
        '
        Me.SETUPToolStripMenuItem.Name = "SETUPToolStripMenuItem"
        Me.SETUPToolStripMenuItem.Size = New System.Drawing.Size(75, 20)
        Me.SETUPToolStripMenuItem.Text = "Front View"
        '
        'ENTRIESToolStripMenuItem
        '
        Me.ENTRIESToolStripMenuItem.Name = "ENTRIESToolStripMenuItem"
        Me.ENTRIESToolStripMenuItem.Size = New System.Drawing.Size(80, 20)
        Me.ENTRIESToolStripMenuItem.Text = "Reservation"
        '
        'REPORTSToolStripMenuItem
        '
        Me.REPORTSToolStripMenuItem.Name = "REPORTSToolStripMenuItem"
        Me.REPORTSToolStripMenuItem.Size = New System.Drawing.Size(62, 20)
        Me.REPORTSToolStripMenuItem.Text = "Checkin"
        '
        'EDITCHANGESToolStripMenuItem
        '
        Me.EDITCHANGESToolStripMenuItem.Name = "EDITCHANGESToolStripMenuItem"
        Me.EDITCHANGESToolStripMenuItem.Size = New System.Drawing.Size(73, 20)
        Me.EDITCHANGESToolStripMenuItem.Text = "Check out"
        '
        'LOGSToolStripMenuItem
        '
        Me.LOGSToolStripMenuItem.Name = "LOGSToolStripMenuItem"
        Me.LOGSToolStripMenuItem.Size = New System.Drawing.Size(107, 20)
        Me.LOGSToolStripMenuItem.Text = "Advance Receipt"
        '
        'HELPToolStripMenuItem
        '
        Me.HELPToolStripMenuItem.Name = "HELPToolStripMenuItem"
        Me.HELPToolStripMenuItem.Size = New System.Drawing.Size(83, 20)
        Me.HELPToolStripMenuItem.Text = "CashRefund"
        '
        'RoomOrderToolStripMenuItem
        '
        Me.RoomOrderToolStripMenuItem.Name = "RoomOrderToolStripMenuItem"
        Me.RoomOrderToolStripMenuItem.Size = New System.Drawing.Size(84, 20)
        Me.RoomOrderToolStripMenuItem.Text = "Room Order"
        '
        'ResturantOrderToolStripMenuItem
        '
        Me.ResturantOrderToolStripMenuItem.Name = "ResturantOrderToolStripMenuItem"
        Me.ResturantOrderToolStripMenuItem.Size = New System.Drawing.Size(99, 20)
        Me.ResturantOrderToolStripMenuItem.Text = "ResturantOrder"
        '
        'ResturrantEntryToolStripMenuItem
        '
        Me.ResturrantEntryToolStripMenuItem.Name = "ResturrantEntryToolStripMenuItem"
        Me.ResturrantEntryToolStripMenuItem.Size = New System.Drawing.Size(103, 20)
        Me.ResturrantEntryToolStripMenuItem.Text = "Resturrant Entry"
        '
        'OtherChangesToolStripMenuItem
        '
        Me.OtherChangesToolStripMenuItem.Name = "OtherChangesToolStripMenuItem"
        Me.OtherChangesToolStripMenuItem.Size = New System.Drawing.Size(98, 20)
        Me.OtherChangesToolStripMenuItem.Text = "Other Changes"
        '
        'BillOnHoldToolStripMenuItem
        '
        Me.BillOnHoldToolStripMenuItem.Name = "BillOnHoldToolStripMenuItem"
        Me.BillOnHoldToolStripMenuItem.Size = New System.Drawing.Size(83, 20)
        Me.BillOnHoldToolStripMenuItem.Text = "Bill On Hold"
        '
        'PanelLeft
        '
        Me.PanelLeft.BackColor = System.Drawing.Color.Gainsboro
        Me.PanelLeft.BackgroundImage = Global.HMS_Forms.My.Resources.Resources.back1
        Me.PanelLeft.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PanelLeft.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelLeft.Location = New System.Drawing.Point(20, 108)
        Me.PanelLeft.Name = "PanelLeft"
        Me.PanelLeft.Size = New System.Drawing.Size(1232, 523)
        Me.PanelLeft.TabIndex = 1
        '
        'PanelRight
        '
        Me.PanelRight.BackColor = System.Drawing.Color.White
        Me.PanelRight.Controls.Add(Me.GroupBox2)
        Me.PanelRight.Dock = System.Windows.Forms.DockStyle.Right
        Me.PanelRight.Location = New System.Drawing.Point(953, 108)
        Me.PanelRight.Name = "PanelRight"
        Me.PanelRight.Size = New System.Drawing.Size(299, 501)
        Me.PanelRight.TabIndex = 0
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.MaterialFlatButton10)
        Me.GroupBox2.Controls.Add(Me.Button10)
        Me.GroupBox2.Controls.Add(Me.MaterialFlatButton9)
        Me.GroupBox2.Controls.Add(Me.Button9)
        Me.GroupBox2.Controls.Add(Me.MaterialFlatButton8)
        Me.GroupBox2.Controls.Add(Me.Button8)
        Me.GroupBox2.Controls.Add(Me.MaterialFlatButton7)
        Me.GroupBox2.Controls.Add(Me.Button7)
        Me.GroupBox2.Controls.Add(Me.MaterialFlatButton6)
        Me.GroupBox2.Controls.Add(Me.Button6)
        Me.GroupBox2.Controls.Add(Me.MaterialFlatButton5)
        Me.GroupBox2.Controls.Add(Me.Button5)
        Me.GroupBox2.Controls.Add(Me.MaterialFlatButton4)
        Me.GroupBox2.Controls.Add(Me.Button4)
        Me.GroupBox2.Controls.Add(Me.MaterialFlatButton3)
        Me.GroupBox2.Controls.Add(Me.Button3)
        Me.GroupBox2.Controls.Add(Me.MaterialFlatButton2)
        Me.GroupBox2.Controls.Add(Me.Button1)
        Me.GroupBox2.Controls.Add(Me.MaterialFlatButton1)
        Me.GroupBox2.Controls.Add(Me.Button2)
        Me.GroupBox2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GroupBox2.Location = New System.Drawing.Point(0, 0)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(299, 501)
        Me.GroupBox2.TabIndex = 22
        Me.GroupBox2.TabStop = False
        '
        'MaterialFlatButton10
        '
        Me.MaterialFlatButton10.AutoSize = True
        Me.MaterialFlatButton10.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.MaterialFlatButton10.Depth = 0
        Me.MaterialFlatButton10.Location = New System.Drawing.Point(69, 454)
        Me.MaterialFlatButton10.Margin = New System.Windows.Forms.Padding(4, 6, 4, 6)
        Me.MaterialFlatButton10.MouseState = MaterialSkin.MouseState.HOVER
        Me.MaterialFlatButton10.Name = "MaterialFlatButton10"
        Me.MaterialFlatButton10.Primary = False
        Me.MaterialFlatButton10.Size = New System.Drawing.Size(93, 36)
        Me.MaterialFlatButton10.TabIndex = 38
        Me.MaterialFlatButton10.Text = "Extra Data"
        Me.MaterialFlatButton10.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.BackColor = System.Drawing.Color.White
        Me.Button10.BackgroundImage = Global.HMS_Forms.My.Resources.Resources.btn
        Me.Button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button10.ForeColor = System.Drawing.Color.Gainsboro
        Me.Button10.Location = New System.Drawing.Point(174, 454)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(93, 36)
        Me.Button10.TabIndex = 39
        Me.Button10.Text = "10"
        Me.Button10.UseVisualStyleBackColor = False
        '
        'MaterialFlatButton9
        '
        Me.MaterialFlatButton9.AutoSize = True
        Me.MaterialFlatButton9.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.MaterialFlatButton9.Depth = 0
        Me.MaterialFlatButton9.Location = New System.Drawing.Point(65, 406)
        Me.MaterialFlatButton9.Margin = New System.Windows.Forms.Padding(4, 6, 4, 6)
        Me.MaterialFlatButton9.MouseState = MaterialSkin.MouseState.HOVER
        Me.MaterialFlatButton9.Name = "MaterialFlatButton9"
        Me.MaterialFlatButton9.Primary = False
        Me.MaterialFlatButton9.Size = New System.Drawing.Size(97, 36)
        Me.MaterialFlatButton9.TabIndex = 36
        Me.MaterialFlatButton9.Text = "Child Guest"
        Me.MaterialFlatButton9.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.BackColor = System.Drawing.Color.White
        Me.Button9.BackgroundImage = Global.HMS_Forms.My.Resources.Resources.btn
        Me.Button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button9.ForeColor = System.Drawing.Color.Gainsboro
        Me.Button9.Location = New System.Drawing.Point(174, 406)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(93, 36)
        Me.Button9.TabIndex = 37
        Me.Button9.Text = "10"
        Me.Button9.UseVisualStyleBackColor = False
        '
        'MaterialFlatButton8
        '
        Me.MaterialFlatButton8.AutoSize = True
        Me.MaterialFlatButton8.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.MaterialFlatButton8.Depth = 0
        Me.MaterialFlatButton8.Location = New System.Drawing.Point(52, 358)
        Me.MaterialFlatButton8.Margin = New System.Windows.Forms.Padding(4, 6, 4, 6)
        Me.MaterialFlatButton8.MouseState = MaterialSkin.MouseState.HOVER
        Me.MaterialFlatButton8.Name = "MaterialFlatButton8"
        Me.MaterialFlatButton8.Primary = False
        Me.MaterialFlatButton8.Size = New System.Drawing.Size(110, 36)
        Me.MaterialFlatButton8.TabIndex = 34
        Me.MaterialFlatButton8.Text = "Female Guest"
        Me.MaterialFlatButton8.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.BackColor = System.Drawing.Color.White
        Me.Button8.BackgroundImage = Global.HMS_Forms.My.Resources.Resources.btn
        Me.Button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button8.ForeColor = System.Drawing.Color.Gainsboro
        Me.Button8.Location = New System.Drawing.Point(174, 358)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(93, 36)
        Me.Button8.TabIndex = 35
        Me.Button8.Text = "10"
        Me.Button8.UseVisualStyleBackColor = False
        '
        'MaterialFlatButton7
        '
        Me.MaterialFlatButton7.AutoSize = True
        Me.MaterialFlatButton7.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.MaterialFlatButton7.Depth = 0
        Me.MaterialFlatButton7.Location = New System.Drawing.Point(68, 310)
        Me.MaterialFlatButton7.Margin = New System.Windows.Forms.Padding(4, 6, 4, 6)
        Me.MaterialFlatButton7.MouseState = MaterialSkin.MouseState.HOVER
        Me.MaterialFlatButton7.Name = "MaterialFlatButton7"
        Me.MaterialFlatButton7.Primary = False
        Me.MaterialFlatButton7.Size = New System.Drawing.Size(94, 36)
        Me.MaterialFlatButton7.TabIndex = 32
        Me.MaterialFlatButton7.Text = "Male Guest"
        Me.MaterialFlatButton7.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.BackColor = System.Drawing.Color.White
        Me.Button7.BackgroundImage = Global.HMS_Forms.My.Resources.Resources.btn
        Me.Button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button7.ForeColor = System.Drawing.Color.Gainsboro
        Me.Button7.Location = New System.Drawing.Point(174, 310)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(93, 36)
        Me.Button7.TabIndex = 33
        Me.Button7.Text = "10"
        Me.Button7.UseVisualStyleBackColor = False
        '
        'MaterialFlatButton6
        '
        Me.MaterialFlatButton6.AutoSize = True
        Me.MaterialFlatButton6.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.MaterialFlatButton6.Depth = 0
        Me.MaterialFlatButton6.Location = New System.Drawing.Point(93, 262)
        Me.MaterialFlatButton6.Margin = New System.Windows.Forms.Padding(4, 6, 4, 6)
        Me.MaterialFlatButton6.MouseState = MaterialSkin.MouseState.HOVER
        Me.MaterialFlatButton6.Name = "MaterialFlatButton6"
        Me.MaterialFlatButton6.Primary = False
        Me.MaterialFlatButton6.Size = New System.Drawing.Size(69, 36)
        Me.MaterialFlatButton6.TabIndex = 30
        Me.MaterialFlatButton6.Text = "Drop up"
        Me.MaterialFlatButton6.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.BackColor = System.Drawing.Color.White
        Me.Button6.BackgroundImage = Global.HMS_Forms.My.Resources.Resources.btn
        Me.Button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button6.ForeColor = System.Drawing.Color.Gainsboro
        Me.Button6.Location = New System.Drawing.Point(174, 262)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(93, 36)
        Me.Button6.TabIndex = 31
        Me.Button6.Text = "10"
        Me.Button6.UseVisualStyleBackColor = False
        '
        'MaterialFlatButton5
        '
        Me.MaterialFlatButton5.AutoSize = True
        Me.MaterialFlatButton5.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.MaterialFlatButton5.Depth = 0
        Me.MaterialFlatButton5.Location = New System.Drawing.Point(102, 214)
        Me.MaterialFlatButton5.Margin = New System.Windows.Forms.Padding(4, 6, 4, 6)
        Me.MaterialFlatButton5.MouseState = MaterialSkin.MouseState.HOVER
        Me.MaterialFlatButton5.Name = "MaterialFlatButton5"
        Me.MaterialFlatButton5.Primary = False
        Me.MaterialFlatButton5.Size = New System.Drawing.Size(60, 36)
        Me.MaterialFlatButton5.TabIndex = 28
        Me.MaterialFlatButton5.Text = "Pickup"
        Me.MaterialFlatButton5.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.Color.White
        Me.Button5.BackgroundImage = Global.HMS_Forms.My.Resources.Resources.btn
        Me.Button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.ForeColor = System.Drawing.Color.Gainsboro
        Me.Button5.Location = New System.Drawing.Point(174, 214)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(93, 36)
        Me.Button5.TabIndex = 29
        Me.Button5.Text = "10"
        Me.Button5.UseVisualStyleBackColor = False
        '
        'MaterialFlatButton4
        '
        Me.MaterialFlatButton4.AutoSize = True
        Me.MaterialFlatButton4.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.MaterialFlatButton4.Depth = 0
        Me.MaterialFlatButton4.Location = New System.Drawing.Point(50, 166)
        Me.MaterialFlatButton4.Margin = New System.Windows.Forms.Padding(4, 6, 4, 6)
        Me.MaterialFlatButton4.MouseState = MaterialSkin.MouseState.HOVER
        Me.MaterialFlatButton4.Name = "MaterialFlatButton4"
        Me.MaterialFlatButton4.Primary = False
        Me.MaterialFlatButton4.Size = New System.Drawing.Size(112, 36)
        Me.MaterialFlatButton4.TabIndex = 26
        Me.MaterialFlatButton4.Text = "Walk in Guest"
        Me.MaterialFlatButton4.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.White
        Me.Button4.BackgroundImage = Global.HMS_Forms.My.Resources.Resources.btn
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.ForeColor = System.Drawing.Color.Gainsboro
        Me.Button4.Location = New System.Drawing.Point(174, 166)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(93, 36)
        Me.Button4.TabIndex = 27
        Me.Button4.Text = "10"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'MaterialFlatButton3
        '
        Me.MaterialFlatButton3.AutoSize = True
        Me.MaterialFlatButton3.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.MaterialFlatButton3.Depth = 0
        Me.MaterialFlatButton3.Location = New System.Drawing.Point(76, 118)
        Me.MaterialFlatButton3.Margin = New System.Windows.Forms.Padding(4, 6, 4, 6)
        Me.MaterialFlatButton3.MouseState = MaterialSkin.MouseState.HOVER
        Me.MaterialFlatButton3.Name = "MaterialFlatButton3"
        Me.MaterialFlatButton3.Primary = False
        Me.MaterialFlatButton3.Size = New System.Drawing.Size(86, 36)
        Me.MaterialFlatButton3.TabIndex = 24
        Me.MaterialFlatButton3.Text = "Check out"
        Me.MaterialFlatButton3.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.White
        Me.Button3.BackgroundImage = Global.HMS_Forms.My.Resources.Resources.btn
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.ForeColor = System.Drawing.Color.Gainsboro
        Me.Button3.Location = New System.Drawing.Point(174, 118)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(93, 36)
        Me.Button3.TabIndex = 25
        Me.Button3.Text = "10"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'MaterialFlatButton2
        '
        Me.MaterialFlatButton2.AutoSize = True
        Me.MaterialFlatButton2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.MaterialFlatButton2.Depth = 0
        Me.MaterialFlatButton2.Location = New System.Drawing.Point(41, 70)
        Me.MaterialFlatButton2.Margin = New System.Windows.Forms.Padding(4, 6, 4, 6)
        Me.MaterialFlatButton2.MouseState = MaterialSkin.MouseState.HOVER
        Me.MaterialFlatButton2.Name = "MaterialFlatButton2"
        Me.MaterialFlatButton2.Primary = False
        Me.MaterialFlatButton2.Size = New System.Drawing.Size(121, 36)
        Me.MaterialFlatButton2.TabIndex = 22
        Me.MaterialFlatButton2.Text = "Checkin Rooms"
        Me.MaterialFlatButton2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.White
        Me.Button1.BackgroundImage = Global.HMS_Forms.My.Resources.Resources.btn
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.Color.Gainsboro
        Me.Button1.Location = New System.Drawing.Point(174, 70)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(93, 36)
        Me.Button1.TabIndex = 23
        Me.Button1.Text = "10"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'MaterialFlatButton1
        '
        Me.MaterialFlatButton1.AutoSize = True
        Me.MaterialFlatButton1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.MaterialFlatButton1.Depth = 0
        Me.MaterialFlatButton1.Location = New System.Drawing.Point(16, 22)
        Me.MaterialFlatButton1.Margin = New System.Windows.Forms.Padding(4, 6, 4, 6)
        Me.MaterialFlatButton1.MouseState = MaterialSkin.MouseState.HOVER
        Me.MaterialFlatButton1.Name = "MaterialFlatButton1"
        Me.MaterialFlatButton1.Primary = False
        Me.MaterialFlatButton1.Size = New System.Drawing.Size(146, 36)
        Me.MaterialFlatButton1.TabIndex = 2
        Me.MaterialFlatButton1.Text = "Expected Arrivals"
        Me.MaterialFlatButton1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.White
        Me.Button2.BackgroundImage = Global.HMS_Forms.My.Resources.Resources.btn
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.ForeColor = System.Drawing.Color.Gainsboro
        Me.Button2.Location = New System.Drawing.Point(174, 22)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(93, 36)
        Me.Button2.TabIndex = 21
        Me.Button2.Text = "10"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.GreenYellow
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel1.Location = New System.Drawing.Point(20, 108)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(200, 523)
        Me.Panel1.TabIndex = 3
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1, Me.ToolStripStatusLabel2})
        Me.StatusStrip1.Location = New System.Drawing.Point(220, 609)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(1032, 22)
        Me.StatusStrip1.TabIndex = 2
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(65, 17)
        Me.ToolStripStatusLabel1.Text = "User Name"
        '
        'ToolStripStatusLabel2
        '
        Me.ToolStripStatusLabel2.Name = "ToolStripStatusLabel2"
        Me.ToolStripStatusLabel2.Size = New System.Drawing.Size(75, 17)
        Me.ToolStripStatusLabel2.Text = "Horizon User"
        '
        'MenuStrip2
        '
        Me.MenuStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SETUToolStripMenuItem, Me.EntriesToolStripMenuItem1, Me.REPORTSToolStripMenuItem1, Me.EDITCHANGESToolStripMenuItem1, Me.LOGSToolStripMenuItem1})
        Me.MenuStrip2.Location = New System.Drawing.Point(20, 60)
        Me.MenuStrip2.Name = "MenuStrip2"
        Me.MenuStrip2.Size = New System.Drawing.Size(1232, 24)
        Me.MenuStrip2.TabIndex = 3
        Me.MenuStrip2.Text = "MenuStrip2"
        '
        'SETUToolStripMenuItem
        '
        Me.SETUToolStripMenuItem.Name = "SETUToolStripMenuItem"
        Me.SETUToolStripMenuItem.Size = New System.Drawing.Size(52, 20)
        Me.SETUToolStripMenuItem.Text = "SETUP"
        '
        'EntriesToolStripMenuItem1
        '
        Me.EntriesToolStripMenuItem1.Name = "EntriesToolStripMenuItem1"
        Me.EntriesToolStripMenuItem1.Size = New System.Drawing.Size(62, 20)
        Me.EntriesToolStripMenuItem1.Text = "ENTRIES"
        '
        'REPORTSToolStripMenuItem1
        '
        Me.REPORTSToolStripMenuItem1.Name = "REPORTSToolStripMenuItem1"
        Me.REPORTSToolStripMenuItem1.Size = New System.Drawing.Size(66, 20)
        Me.REPORTSToolStripMenuItem1.Text = "REPORTS"
        '
        'EDITCHANGESToolStripMenuItem1
        '
        Me.EDITCHANGESToolStripMenuItem1.Name = "EDITCHANGESToolStripMenuItem1"
        Me.EDITCHANGESToolStripMenuItem1.Size = New System.Drawing.Size(101, 20)
        Me.EDITCHANGESToolStripMenuItem1.Text = "EDIT/CHANGES"
        '
        'LOGSToolStripMenuItem1
        '
        Me.LOGSToolStripMenuItem1.Name = "LOGSToolStripMenuItem1"
        Me.LOGSToolStripMenuItem1.Size = New System.Drawing.Size(48, 20)
        Me.LOGSToolStripMenuItem1.Text = "LOGS"
        '
        'frontDesk
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoValidate = System.Windows.Forms.AutoValidate.EnableAllowFocusChange
        Me.ClientSize = New System.Drawing.Size(1272, 651)
        Me.Controls.Add(Me.PanelRight)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.PanelLeft)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.MenuStrip2)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.ImeMode = System.Windows.Forms.ImeMode.[On]
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "frontDesk"
        Me.Text = "Hospitality Management System"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.PanelRight.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.MenuStrip2.ResumeLayout(False)
        Me.MenuStrip2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents SETUPToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ENTRIESToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents REPORTSToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EDITCHANGESToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LOGSToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HELPToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PanelLeft As Panel
    Friend WithEvents PanelRight As Panel
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents MaterialFlatButton10 As MaterialSkin.Controls.MaterialFlatButton
    Friend WithEvents Button10 As Button
    Friend WithEvents MaterialFlatButton9 As MaterialSkin.Controls.MaterialFlatButton
    Friend WithEvents Button9 As Button
    Friend WithEvents MaterialFlatButton8 As MaterialSkin.Controls.MaterialFlatButton
    Friend WithEvents Button8 As Button
    Friend WithEvents MaterialFlatButton7 As MaterialSkin.Controls.MaterialFlatButton
    Friend WithEvents Button7 As Button
    Friend WithEvents MaterialFlatButton6 As MaterialSkin.Controls.MaterialFlatButton
    Friend WithEvents Button6 As Button
    Friend WithEvents MaterialFlatButton5 As MaterialSkin.Controls.MaterialFlatButton
    Friend WithEvents Button5 As Button
    Friend WithEvents MaterialFlatButton4 As MaterialSkin.Controls.MaterialFlatButton
    Friend WithEvents Button4 As Button
    Friend WithEvents MaterialFlatButton3 As MaterialSkin.Controls.MaterialFlatButton
    Friend WithEvents Button3 As Button
    Friend WithEvents MaterialFlatButton2 As MaterialSkin.Controls.MaterialFlatButton
    Friend WithEvents Button1 As Button
    Friend WithEvents MaterialFlatButton1 As MaterialSkin.Controls.MaterialFlatButton
    Friend WithEvents Button2 As Button
    Friend WithEvents StatusStrip1 As StatusStrip
    Friend WithEvents Panel1 As Panel
    Friend WithEvents ToolStripStatusLabel1 As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel2 As ToolStripStatusLabel
    Friend WithEvents MenuStrip2 As MenuStrip
    Friend WithEvents SETUToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents EntriesToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents REPORTSToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents EDITCHANGESToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents LOGSToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents RoomOrderToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ResturantOrderToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ResturrantEntryToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents OtherChangesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents BillOnHoldToolStripMenuItem As ToolStripMenuItem
End Class
