﻿Public Class CustomerRoomDetails

End Class