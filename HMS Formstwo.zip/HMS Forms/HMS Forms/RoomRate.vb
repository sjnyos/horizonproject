﻿Public Class RoomRate

End Class