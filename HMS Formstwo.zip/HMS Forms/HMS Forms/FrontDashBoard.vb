﻿Public Class FrontDashBoard
    Private Sub ENTRIESToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ENTRIESToolStripMenuItem.Click

        Dim frm1 As New reservationForm
        frm1.MdiParent = Me
        frm1.Show()
    End Sub

    Private Sub FrontDashBoard_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim frm As New FrontDeskDetailViewForm

        frm.MdiParent = Me
        frm.Show()


    End Sub

    Private Sub REPORTSToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles REPORTSToolStripMenuItem.Click
        Dim frm As New CheckInDetails


        frm.MdiParent = Me
        frm.Show()
    End Sub

    Private Sub MaterialFlatButton2_Click(sender As Object, e As EventArgs) Handles MaterialFlatButton2.Click

    End Sub

    Private Sub EDITCHANGESToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EDITCHANGESToolStripMenuItem.Click
        Dim frm As New Checkout
        frm.MdiParent = Me
        frm.Show()
    End Sub
End Class