﻿Public Class Checkout
    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Dim FRM2 As New PassportDetails

        FRM2.ShowDialog()
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Dim FRM2 As New CountryForm


        FRM2.ShowDialog()
    End Sub
End Class