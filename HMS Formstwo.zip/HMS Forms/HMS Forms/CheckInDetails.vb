﻿Public Class CheckInDetails
    Private Sub Label1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label15_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label16_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub GroupBox3_Enter(sender As Object, e As EventArgs) Handles GroupBox3.Enter

    End Sub

    Private Sub GroupBox5_Enter(sender As Object, e As EventArgs) Handles GroupBox5.Enter

    End Sub

    Private Sub MaterialRaisedButton10_Click(sender As Object, e As EventArgs)
        Dim FRM1 As New CustomerRoomDetails
        FRM1.ShowDialog()

    End Sub

    Private Sub MaterialRaisedButton8_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim FRM2 As New RoomSelectForm
        FRM2.ShowDialog()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim FRM2 As New SearchReservationFrom

        FRM2.ShowDialog()
    End Sub

    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        Dim FRM2 As New SearchGuests
        FRM2.ShowDialog()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Dim FRM2 As New PassportDetails

        FRM2.ShowDialog()
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Dim FRM2 As New CountryForm


        FRM2.ShowDialog()
    End Sub
End Class