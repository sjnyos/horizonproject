﻿Public Class invoiceProcesses
    Private Sub ENTRIESToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ENTRIESToolStripMenuItem.Click

    End Sub
End Class