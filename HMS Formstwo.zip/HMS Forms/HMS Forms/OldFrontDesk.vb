﻿Public Class OldFrontDesk
    Private Sub AbcdToolStripMenuItem_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub MaterialFlatButton2_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub SETUPToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SETUPToolStripMenuItem.Click

    End Sub

    Private Sub SetupToolStripMenuItem1_Click(sender As Object, e As EventArgs)

    End Sub
End Class