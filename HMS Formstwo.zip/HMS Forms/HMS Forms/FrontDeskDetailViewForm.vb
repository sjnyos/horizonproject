﻿Public Class FrontDeskDetailViewForm
    Private Sub DataGridView2_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView2.CellContentClick

    End Sub

    Private Sub ToolStripStatusLabel1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub FrontDeskDetailViewForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class