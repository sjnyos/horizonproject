﻿Public Class RoomStatus

End Class