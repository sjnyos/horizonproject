﻿Public Class HrStockLists

End Class