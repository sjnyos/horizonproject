﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class RoomSelectForm
    Inherits MetroFramework.Forms.MetroForm


    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.FlowLayoutPanel1 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Panel7 = New System.Windows.Forms.Panel()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Panel8 = New System.Windows.Forms.Panel()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Panel9 = New System.Windows.Forms.Panel()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Panel10 = New System.Windows.Forms.Panel()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Panel11 = New System.Windows.Forms.Panel()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Panel12 = New System.Windows.Forms.Panel()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.Panel13 = New System.Windows.Forms.Panel()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.Panel14 = New System.Windows.Forms.Panel()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.Panel15 = New System.Windows.Forms.Panel()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.Label61 = New System.Windows.Forms.Label()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.Label64 = New System.Windows.Forms.Label()
        Me.Panel16 = New System.Windows.Forms.Panel()
        Me.Button16 = New System.Windows.Forms.Button()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.Label66 = New System.Windows.Forms.Label()
        Me.Label67 = New System.Windows.Forms.Label()
        Me.Label68 = New System.Windows.Forms.Label()
        Me.Panel17 = New System.Windows.Forms.Panel()
        Me.Button17 = New System.Windows.Forms.Button()
        Me.Label69 = New System.Windows.Forms.Label()
        Me.Label70 = New System.Windows.Forms.Label()
        Me.Label71 = New System.Windows.Forms.Label()
        Me.Label72 = New System.Windows.Forms.Label()
        Me.Panel18 = New System.Windows.Forms.Panel()
        Me.Button18 = New System.Windows.Forms.Button()
        Me.Label73 = New System.Windows.Forms.Label()
        Me.Label74 = New System.Windows.Forms.Label()
        Me.Label75 = New System.Windows.Forms.Label()
        Me.Label76 = New System.Windows.Forms.Label()
        Me.Panel20 = New System.Windows.Forms.Panel()
        Me.Button19 = New System.Windows.Forms.Button()
        Me.Label77 = New System.Windows.Forms.Label()
        Me.Label78 = New System.Windows.Forms.Label()
        Me.Label79 = New System.Windows.Forms.Label()
        Me.Label80 = New System.Windows.Forms.Label()
        Me.Panel21 = New System.Windows.Forms.Panel()
        Me.Button20 = New System.Windows.Forms.Button()
        Me.Label81 = New System.Windows.Forms.Label()
        Me.Label82 = New System.Windows.Forms.Label()
        Me.Label83 = New System.Windows.Forms.Label()
        Me.Label84 = New System.Windows.Forms.Label()
        Me.Panel22 = New System.Windows.Forms.Panel()
        Me.Button21 = New System.Windows.Forms.Button()
        Me.Label85 = New System.Windows.Forms.Label()
        Me.Label86 = New System.Windows.Forms.Label()
        Me.Label87 = New System.Windows.Forms.Label()
        Me.Label88 = New System.Windows.Forms.Label()
        Me.Panel23 = New System.Windows.Forms.Panel()
        Me.Button22 = New System.Windows.Forms.Button()
        Me.Label89 = New System.Windows.Forms.Label()
        Me.Label90 = New System.Windows.Forms.Label()
        Me.Label91 = New System.Windows.Forms.Label()
        Me.Label92 = New System.Windows.Forms.Label()
        Me.Panel24 = New System.Windows.Forms.Panel()
        Me.Button23 = New System.Windows.Forms.Button()
        Me.Label93 = New System.Windows.Forms.Label()
        Me.Label94 = New System.Windows.Forms.Label()
        Me.Label95 = New System.Windows.Forms.Label()
        Me.Label96 = New System.Windows.Forms.Label()
        Me.Panel25 = New System.Windows.Forms.Panel()
        Me.Button24 = New System.Windows.Forms.Button()
        Me.Label97 = New System.Windows.Forms.Label()
        Me.Label98 = New System.Windows.Forms.Label()
        Me.Label99 = New System.Windows.Forms.Label()
        Me.Label100 = New System.Windows.Forms.Label()
        Me.Panel26 = New System.Windows.Forms.Panel()
        Me.Button25 = New System.Windows.Forms.Button()
        Me.Label101 = New System.Windows.Forms.Label()
        Me.Label102 = New System.Windows.Forms.Label()
        Me.Label103 = New System.Windows.Forms.Label()
        Me.Label104 = New System.Windows.Forms.Label()
        Me.Panel27 = New System.Windows.Forms.Panel()
        Me.Button26 = New System.Windows.Forms.Button()
        Me.Label105 = New System.Windows.Forms.Label()
        Me.Label106 = New System.Windows.Forms.Label()
        Me.Label107 = New System.Windows.Forms.Label()
        Me.Label108 = New System.Windows.Forms.Label()
        Me.Panel28 = New System.Windows.Forms.Panel()
        Me.Button27 = New System.Windows.Forms.Button()
        Me.Label109 = New System.Windows.Forms.Label()
        Me.Label110 = New System.Windows.Forms.Label()
        Me.Label111 = New System.Windows.Forms.Label()
        Me.Label112 = New System.Windows.Forms.Label()
        Me.Panel29 = New System.Windows.Forms.Panel()
        Me.Button28 = New System.Windows.Forms.Button()
        Me.Label113 = New System.Windows.Forms.Label()
        Me.Label114 = New System.Windows.Forms.Label()
        Me.Label115 = New System.Windows.Forms.Label()
        Me.Label116 = New System.Windows.Forms.Label()
        Me.Panel30 = New System.Windows.Forms.Panel()
        Me.Button29 = New System.Windows.Forms.Button()
        Me.Label117 = New System.Windows.Forms.Label()
        Me.Label118 = New System.Windows.Forms.Label()
        Me.Label119 = New System.Windows.Forms.Label()
        Me.Label120 = New System.Windows.Forms.Label()
        Me.Panel31 = New System.Windows.Forms.Panel()
        Me.Button30 = New System.Windows.Forms.Button()
        Me.Label121 = New System.Windows.Forms.Label()
        Me.Label122 = New System.Windows.Forms.Label()
        Me.Label123 = New System.Windows.Forms.Label()
        Me.Label124 = New System.Windows.Forms.Label()
        Me.Panel32 = New System.Windows.Forms.Panel()
        Me.Button31 = New System.Windows.Forms.Button()
        Me.Label125 = New System.Windows.Forms.Label()
        Me.Label126 = New System.Windows.Forms.Label()
        Me.Label127 = New System.Windows.Forms.Label()
        Me.Label128 = New System.Windows.Forms.Label()
        Me.Panel33 = New System.Windows.Forms.Panel()
        Me.Button32 = New System.Windows.Forms.Button()
        Me.Label129 = New System.Windows.Forms.Label()
        Me.Label130 = New System.Windows.Forms.Label()
        Me.Label131 = New System.Windows.Forms.Label()
        Me.Label132 = New System.Windows.Forms.Label()
        Me.MaterialTabControl1 = New MaterialSkin.Controls.MaterialTabControl()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.MaterialTabSelector1 = New MaterialSkin.Controls.MaterialTabSelector()
        Me.Panel19 = New System.Windows.Forms.Panel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.MetroDateTime1 = New MetroFramework.Controls.MetroDateTime()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel3 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel4 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel5 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.MaterialRaisedButton1 = New MaterialSkin.Controls.MaterialRaisedButton()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label133 = New System.Windows.Forms.Label()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.Label134 = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.roomno = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Roomasdfdas = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.RoomStatusss = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Peopleasdf = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.guestname = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.contactno = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.noofpeople = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CheckIN = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Checkoutdate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.RoomService = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.KitchenService = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label135 = New System.Windows.Forms.Label()
        Me.DataGridView2 = New System.Windows.Forms.DataGridView()
        Me.Label136 = New System.Windows.Forms.Label()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.RoomCheckoutTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SendRoomService = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.TabPage2.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.FlowLayoutPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.Panel7.SuspendLayout()
        Me.Panel8.SuspendLayout()
        Me.Panel9.SuspendLayout()
        Me.Panel10.SuspendLayout()
        Me.Panel11.SuspendLayout()
        Me.Panel12.SuspendLayout()
        Me.Panel13.SuspendLayout()
        Me.Panel14.SuspendLayout()
        Me.Panel15.SuspendLayout()
        Me.Panel16.SuspendLayout()
        Me.Panel17.SuspendLayout()
        Me.Panel18.SuspendLayout()
        Me.Panel20.SuspendLayout()
        Me.Panel21.SuspendLayout()
        Me.Panel22.SuspendLayout()
        Me.Panel23.SuspendLayout()
        Me.Panel24.SuspendLayout()
        Me.Panel25.SuspendLayout()
        Me.Panel26.SuspendLayout()
        Me.Panel27.SuspendLayout()
        Me.Panel28.SuspendLayout()
        Me.Panel29.SuspendLayout()
        Me.Panel30.SuspendLayout()
        Me.Panel31.SuspendLayout()
        Me.Panel32.SuspendLayout()
        Me.Panel33.SuspendLayout()
        Me.MaterialTabControl1.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.Panel19.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.Label135)
        Me.TabPage2.Controls.Add(Me.DataGridView1)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(965, 518)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Room Status"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.FlowLayoutPanel1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(965, 518)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Room Selection"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'FlowLayoutPanel1
        '
        Me.FlowLayoutPanel1.AutoScroll = True
        Me.FlowLayoutPanel1.AutoSize = True
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel1)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel2)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel3)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel4)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel5)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel6)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel7)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel8)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel9)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel10)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel11)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel12)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel13)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel14)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel15)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel16)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel17)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel18)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel20)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel21)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel22)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel23)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel24)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel25)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel26)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel27)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel28)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel29)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel30)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel31)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel32)
        Me.FlowLayoutPanel1.Controls.Add(Me.Panel33)
        Me.FlowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FlowLayoutPanel1.FlowDirection = System.Windows.Forms.FlowDirection.TopDown
        Me.FlowLayoutPanel1.Location = New System.Drawing.Point(3, 3)
        Me.FlowLayoutPanel1.Name = "FlowLayoutPanel1"
        Me.FlowLayoutPanel1.Size = New System.Drawing.Size(959, 512)
        Me.FlowLayoutPanel1.TabIndex = 0
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.ForestGreen
        Me.Panel1.Controls.Add(Me.Button1)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Location = New System.Drawing.Point(3, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(113, 143)
        Me.Panel1.TabIndex = 0
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(7, 107)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(91, 30)
        Me.Button1.TabIndex = 4
        Me.Button1.Text = "Select"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Transparent
        Me.Label6.Location = New System.Drawing.Point(18, 84)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(74, 15)
        Me.Label6.TabIndex = 3
        Me.Label6.Text = "2 Bedrooms"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Transparent
        Me.Label5.Location = New System.Drawing.Point(23, 62)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(64, 15)
        Me.Label5.TabIndex = 2
        Me.Label5.Text = "Size : XXX"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Transparent
        Me.Label4.Location = New System.Drawing.Point(6, 41)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(98, 15)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "Starndard Room"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Transparent
        Me.Label3.Location = New System.Drawing.Point(24, 7)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(62, 31)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "101"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.ForestGreen
        Me.Panel2.Controls.Add(Me.Button2)
        Me.Panel2.Controls.Add(Me.Label8)
        Me.Panel2.Controls.Add(Me.Label9)
        Me.Panel2.Controls.Add(Me.Label10)
        Me.Panel2.Controls.Add(Me.Label11)
        Me.Panel2.Location = New System.Drawing.Point(3, 152)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(113, 143)
        Me.Panel2.TabIndex = 1
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(7, 107)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(91, 30)
        Me.Button2.TabIndex = 4
        Me.Button2.Text = "Select"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.Transparent
        Me.Label8.Location = New System.Drawing.Point(18, 84)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(74, 15)
        Me.Label8.TabIndex = 3
        Me.Label8.Text = "2 Bedrooms"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.Transparent
        Me.Label9.Location = New System.Drawing.Point(23, 62)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(64, 15)
        Me.Label9.TabIndex = 2
        Me.Label9.Text = "Size : XXX"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.Transparent
        Me.Label10.Location = New System.Drawing.Point(6, 41)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(98, 15)
        Me.Label10.TabIndex = 1
        Me.Label10.Text = "Starndard Room"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.Transparent
        Me.Label11.Location = New System.Drawing.Point(24, 7)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(62, 31)
        Me.Label11.TabIndex = 0
        Me.Label11.Text = "101"
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.ForestGreen
        Me.Panel3.Controls.Add(Me.Button3)
        Me.Panel3.Controls.Add(Me.Label13)
        Me.Panel3.Controls.Add(Me.Label14)
        Me.Panel3.Controls.Add(Me.Label15)
        Me.Panel3.Controls.Add(Me.Label16)
        Me.Panel3.Location = New System.Drawing.Point(3, 301)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(113, 143)
        Me.Panel3.TabIndex = 2
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(7, 107)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(91, 30)
        Me.Button3.TabIndex = 4
        Me.Button3.Text = "Select"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.Transparent
        Me.Label13.Location = New System.Drawing.Point(18, 84)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(74, 15)
        Me.Label13.TabIndex = 3
        Me.Label13.Text = "2 Bedrooms"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.Transparent
        Me.Label14.Location = New System.Drawing.Point(23, 62)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(64, 15)
        Me.Label14.TabIndex = 2
        Me.Label14.Text = "Size : XXX"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.Transparent
        Me.Label15.Location = New System.Drawing.Point(6, 41)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(98, 15)
        Me.Label15.TabIndex = 1
        Me.Label15.Text = "Starndard Room"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.Transparent
        Me.Label16.Location = New System.Drawing.Point(24, 7)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(62, 31)
        Me.Label16.TabIndex = 0
        Me.Label16.Text = "101"
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.ForestGreen
        Me.Panel4.Controls.Add(Me.Button4)
        Me.Panel4.Controls.Add(Me.Label17)
        Me.Panel4.Controls.Add(Me.Label18)
        Me.Panel4.Controls.Add(Me.Label19)
        Me.Panel4.Controls.Add(Me.Label20)
        Me.Panel4.Location = New System.Drawing.Point(122, 3)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(113, 143)
        Me.Panel4.TabIndex = 3
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(7, 107)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(91, 30)
        Me.Button4.TabIndex = 4
        Me.Button4.Text = "Select"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.Transparent
        Me.Label17.Location = New System.Drawing.Point(18, 84)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(74, 15)
        Me.Label17.TabIndex = 3
        Me.Label17.Text = "2 Bedrooms"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.Color.Transparent
        Me.Label18.Location = New System.Drawing.Point(23, 62)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(64, 15)
        Me.Label18.TabIndex = 2
        Me.Label18.Text = "Size : XXX"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.Transparent
        Me.Label19.Location = New System.Drawing.Point(6, 41)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(98, 15)
        Me.Label19.TabIndex = 1
        Me.Label19.Text = "Starndard Room"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.ForeColor = System.Drawing.Color.Transparent
        Me.Label20.Location = New System.Drawing.Point(24, 7)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(62, 31)
        Me.Label20.TabIndex = 0
        Me.Label20.Text = "101"
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.Goldenrod
        Me.Panel5.Controls.Add(Me.Button5)
        Me.Panel5.Controls.Add(Me.Label21)
        Me.Panel5.Controls.Add(Me.Label22)
        Me.Panel5.Controls.Add(Me.Label23)
        Me.Panel5.Controls.Add(Me.Label24)
        Me.Panel5.Location = New System.Drawing.Point(122, 152)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(113, 143)
        Me.Panel5.TabIndex = 4
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(7, 107)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(91, 30)
        Me.Button5.TabIndex = 4
        Me.Button5.Text = "Select"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.ForeColor = System.Drawing.Color.Transparent
        Me.Label21.Location = New System.Drawing.Point(18, 84)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(74, 15)
        Me.Label21.TabIndex = 3
        Me.Label21.Text = "2 Bedrooms"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.ForeColor = System.Drawing.Color.Transparent
        Me.Label22.Location = New System.Drawing.Point(23, 62)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(64, 15)
        Me.Label22.TabIndex = 2
        Me.Label22.Text = "Size : XXX"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.ForeColor = System.Drawing.Color.Transparent
        Me.Label23.Location = New System.Drawing.Point(6, 41)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(98, 15)
        Me.Label23.TabIndex = 1
        Me.Label23.Text = "Starndard Room"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.ForeColor = System.Drawing.Color.Transparent
        Me.Label24.Location = New System.Drawing.Point(24, 7)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(62, 31)
        Me.Label24.TabIndex = 0
        Me.Label24.Text = "101"
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.Color.ForestGreen
        Me.Panel6.Controls.Add(Me.Button6)
        Me.Panel6.Controls.Add(Me.Label25)
        Me.Panel6.Controls.Add(Me.Label26)
        Me.Panel6.Controls.Add(Me.Label27)
        Me.Panel6.Controls.Add(Me.Label28)
        Me.Panel6.Location = New System.Drawing.Point(122, 301)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(113, 143)
        Me.Panel6.TabIndex = 5
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(7, 107)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(91, 30)
        Me.Button6.TabIndex = 4
        Me.Button6.Text = "Select"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.ForeColor = System.Drawing.Color.Transparent
        Me.Label25.Location = New System.Drawing.Point(18, 84)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(74, 15)
        Me.Label25.TabIndex = 3
        Me.Label25.Text = "2 Bedrooms"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.ForeColor = System.Drawing.Color.Transparent
        Me.Label26.Location = New System.Drawing.Point(23, 62)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(64, 15)
        Me.Label26.TabIndex = 2
        Me.Label26.Text = "Size : XXX"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.ForeColor = System.Drawing.Color.Transparent
        Me.Label27.Location = New System.Drawing.Point(6, 41)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(98, 15)
        Me.Label27.TabIndex = 1
        Me.Label27.Text = "Starndard Room"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.ForeColor = System.Drawing.Color.Transparent
        Me.Label28.Location = New System.Drawing.Point(24, 7)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(62, 31)
        Me.Label28.TabIndex = 0
        Me.Label28.Text = "101"
        '
        'Panel7
        '
        Me.Panel7.BackColor = System.Drawing.Color.ForestGreen
        Me.Panel7.Controls.Add(Me.Button7)
        Me.Panel7.Controls.Add(Me.Label29)
        Me.Panel7.Controls.Add(Me.Label30)
        Me.Panel7.Controls.Add(Me.Label31)
        Me.Panel7.Controls.Add(Me.Label32)
        Me.Panel7.Location = New System.Drawing.Point(241, 3)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(113, 143)
        Me.Panel7.TabIndex = 6
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(7, 107)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(91, 30)
        Me.Button7.TabIndex = 4
        Me.Button7.Text = "Select"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.ForeColor = System.Drawing.Color.Transparent
        Me.Label29.Location = New System.Drawing.Point(18, 84)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(74, 15)
        Me.Label29.TabIndex = 3
        Me.Label29.Text = "2 Bedrooms"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label30.ForeColor = System.Drawing.Color.Transparent
        Me.Label30.Location = New System.Drawing.Point(23, 62)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(64, 15)
        Me.Label30.TabIndex = 2
        Me.Label30.Text = "Size : XXX"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label31.ForeColor = System.Drawing.Color.Transparent
        Me.Label31.Location = New System.Drawing.Point(6, 41)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(98, 15)
        Me.Label31.TabIndex = 1
        Me.Label31.Text = "Starndard Room"
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label32.ForeColor = System.Drawing.Color.Transparent
        Me.Label32.Location = New System.Drawing.Point(24, 7)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(62, 31)
        Me.Label32.TabIndex = 0
        Me.Label32.Text = "101"
        '
        'Panel8
        '
        Me.Panel8.BackColor = System.Drawing.Color.ForestGreen
        Me.Panel8.Controls.Add(Me.Button8)
        Me.Panel8.Controls.Add(Me.Label33)
        Me.Panel8.Controls.Add(Me.Label34)
        Me.Panel8.Controls.Add(Me.Label35)
        Me.Panel8.Controls.Add(Me.Label36)
        Me.Panel8.Location = New System.Drawing.Point(241, 152)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(113, 143)
        Me.Panel8.TabIndex = 7
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(7, 107)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(91, 30)
        Me.Button8.TabIndex = 4
        Me.Button8.Text = "Select"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label33.ForeColor = System.Drawing.Color.Transparent
        Me.Label33.Location = New System.Drawing.Point(18, 84)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(74, 15)
        Me.Label33.TabIndex = 3
        Me.Label33.Text = "2 Bedrooms"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label34.ForeColor = System.Drawing.Color.Transparent
        Me.Label34.Location = New System.Drawing.Point(23, 62)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(64, 15)
        Me.Label34.TabIndex = 2
        Me.Label34.Text = "Size : XXX"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label35.ForeColor = System.Drawing.Color.Transparent
        Me.Label35.Location = New System.Drawing.Point(6, 41)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(98, 15)
        Me.Label35.TabIndex = 1
        Me.Label35.Text = "Starndard Room"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label36.ForeColor = System.Drawing.Color.Transparent
        Me.Label36.Location = New System.Drawing.Point(24, 7)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(62, 31)
        Me.Label36.TabIndex = 0
        Me.Label36.Text = "101"
        '
        'Panel9
        '
        Me.Panel9.BackColor = System.Drawing.Color.ForestGreen
        Me.Panel9.Controls.Add(Me.Button9)
        Me.Panel9.Controls.Add(Me.Label37)
        Me.Panel9.Controls.Add(Me.Label38)
        Me.Panel9.Controls.Add(Me.Label39)
        Me.Panel9.Controls.Add(Me.Label40)
        Me.Panel9.Location = New System.Drawing.Point(241, 301)
        Me.Panel9.Name = "Panel9"
        Me.Panel9.Size = New System.Drawing.Size(113, 143)
        Me.Panel9.TabIndex = 8
        '
        'Button9
        '
        Me.Button9.Location = New System.Drawing.Point(7, 107)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(91, 30)
        Me.Button9.TabIndex = 4
        Me.Button9.Text = "Select"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label37.ForeColor = System.Drawing.Color.Transparent
        Me.Label37.Location = New System.Drawing.Point(18, 84)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(74, 15)
        Me.Label37.TabIndex = 3
        Me.Label37.Text = "2 Bedrooms"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label38.ForeColor = System.Drawing.Color.Transparent
        Me.Label38.Location = New System.Drawing.Point(23, 62)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(64, 15)
        Me.Label38.TabIndex = 2
        Me.Label38.Text = "Size : XXX"
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label39.ForeColor = System.Drawing.Color.Transparent
        Me.Label39.Location = New System.Drawing.Point(6, 41)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(98, 15)
        Me.Label39.TabIndex = 1
        Me.Label39.Text = "Starndard Room"
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label40.ForeColor = System.Drawing.Color.Transparent
        Me.Label40.Location = New System.Drawing.Point(24, 7)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(62, 31)
        Me.Label40.TabIndex = 0
        Me.Label40.Text = "101"
        '
        'Panel10
        '
        Me.Panel10.BackColor = System.Drawing.Color.Red
        Me.Panel10.Controls.Add(Me.Button10)
        Me.Panel10.Controls.Add(Me.Label41)
        Me.Panel10.Controls.Add(Me.Label42)
        Me.Panel10.Controls.Add(Me.Label43)
        Me.Panel10.Controls.Add(Me.Label44)
        Me.Panel10.Location = New System.Drawing.Point(360, 3)
        Me.Panel10.Name = "Panel10"
        Me.Panel10.Size = New System.Drawing.Size(113, 143)
        Me.Panel10.TabIndex = 9
        '
        'Button10
        '
        Me.Button10.Location = New System.Drawing.Point(7, 107)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(91, 30)
        Me.Button10.TabIndex = 4
        Me.Button10.Text = "Select"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label41.ForeColor = System.Drawing.Color.Transparent
        Me.Label41.Location = New System.Drawing.Point(18, 84)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(74, 15)
        Me.Label41.TabIndex = 3
        Me.Label41.Text = "2 Bedrooms"
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label42.ForeColor = System.Drawing.Color.Transparent
        Me.Label42.Location = New System.Drawing.Point(23, 62)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(64, 15)
        Me.Label42.TabIndex = 2
        Me.Label42.Text = "Size : XXX"
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label43.ForeColor = System.Drawing.Color.Transparent
        Me.Label43.Location = New System.Drawing.Point(6, 41)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(98, 15)
        Me.Label43.TabIndex = 1
        Me.Label43.Text = "Starndard Room"
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label44.ForeColor = System.Drawing.Color.Transparent
        Me.Label44.Location = New System.Drawing.Point(24, 7)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(62, 31)
        Me.Label44.TabIndex = 0
        Me.Label44.Text = "101"
        '
        'Panel11
        '
        Me.Panel11.BackColor = System.Drawing.Color.ForestGreen
        Me.Panel11.Controls.Add(Me.Button11)
        Me.Panel11.Controls.Add(Me.Label45)
        Me.Panel11.Controls.Add(Me.Label46)
        Me.Panel11.Controls.Add(Me.Label47)
        Me.Panel11.Controls.Add(Me.Label48)
        Me.Panel11.Location = New System.Drawing.Point(360, 152)
        Me.Panel11.Name = "Panel11"
        Me.Panel11.Size = New System.Drawing.Size(113, 143)
        Me.Panel11.TabIndex = 10
        '
        'Button11
        '
        Me.Button11.Location = New System.Drawing.Point(7, 107)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(91, 30)
        Me.Button11.TabIndex = 4
        Me.Button11.Text = "Select"
        Me.Button11.UseVisualStyleBackColor = True
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label45.ForeColor = System.Drawing.Color.Transparent
        Me.Label45.Location = New System.Drawing.Point(18, 84)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(74, 15)
        Me.Label45.TabIndex = 3
        Me.Label45.Text = "2 Bedrooms"
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label46.ForeColor = System.Drawing.Color.Transparent
        Me.Label46.Location = New System.Drawing.Point(23, 62)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(64, 15)
        Me.Label46.TabIndex = 2
        Me.Label46.Text = "Size : XXX"
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label47.ForeColor = System.Drawing.Color.Transparent
        Me.Label47.Location = New System.Drawing.Point(6, 41)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(98, 15)
        Me.Label47.TabIndex = 1
        Me.Label47.Text = "Starndard Room"
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label48.ForeColor = System.Drawing.Color.Transparent
        Me.Label48.Location = New System.Drawing.Point(24, 7)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(62, 31)
        Me.Label48.TabIndex = 0
        Me.Label48.Text = "101"
        '
        'Panel12
        '
        Me.Panel12.BackColor = System.Drawing.Color.Red
        Me.Panel12.Controls.Add(Me.Button12)
        Me.Panel12.Controls.Add(Me.Label49)
        Me.Panel12.Controls.Add(Me.Label50)
        Me.Panel12.Controls.Add(Me.Label51)
        Me.Panel12.Controls.Add(Me.Label52)
        Me.Panel12.Location = New System.Drawing.Point(360, 301)
        Me.Panel12.Name = "Panel12"
        Me.Panel12.Size = New System.Drawing.Size(113, 143)
        Me.Panel12.TabIndex = 11
        '
        'Button12
        '
        Me.Button12.Location = New System.Drawing.Point(7, 107)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(91, 30)
        Me.Button12.TabIndex = 4
        Me.Button12.Text = "Select"
        Me.Button12.UseVisualStyleBackColor = True
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label49.ForeColor = System.Drawing.Color.Transparent
        Me.Label49.Location = New System.Drawing.Point(18, 84)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(74, 15)
        Me.Label49.TabIndex = 3
        Me.Label49.Text = "2 Bedrooms"
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label50.ForeColor = System.Drawing.Color.Transparent
        Me.Label50.Location = New System.Drawing.Point(23, 62)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(64, 15)
        Me.Label50.TabIndex = 2
        Me.Label50.Text = "Size : XXX"
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label51.ForeColor = System.Drawing.Color.Transparent
        Me.Label51.Location = New System.Drawing.Point(6, 41)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(98, 15)
        Me.Label51.TabIndex = 1
        Me.Label51.Text = "Starndard Room"
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label52.ForeColor = System.Drawing.Color.Transparent
        Me.Label52.Location = New System.Drawing.Point(24, 7)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(62, 31)
        Me.Label52.TabIndex = 0
        Me.Label52.Text = "101"
        '
        'Panel13
        '
        Me.Panel13.BackColor = System.Drawing.Color.ForestGreen
        Me.Panel13.Controls.Add(Me.Button13)
        Me.Panel13.Controls.Add(Me.Label53)
        Me.Panel13.Controls.Add(Me.Label54)
        Me.Panel13.Controls.Add(Me.Label55)
        Me.Panel13.Controls.Add(Me.Label56)
        Me.Panel13.Location = New System.Drawing.Point(479, 3)
        Me.Panel13.Name = "Panel13"
        Me.Panel13.Size = New System.Drawing.Size(113, 143)
        Me.Panel13.TabIndex = 12
        '
        'Button13
        '
        Me.Button13.Location = New System.Drawing.Point(7, 107)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(91, 30)
        Me.Button13.TabIndex = 4
        Me.Button13.Text = "Select"
        Me.Button13.UseVisualStyleBackColor = True
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label53.ForeColor = System.Drawing.Color.Transparent
        Me.Label53.Location = New System.Drawing.Point(18, 84)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(74, 15)
        Me.Label53.TabIndex = 3
        Me.Label53.Text = "2 Bedrooms"
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label54.ForeColor = System.Drawing.Color.Transparent
        Me.Label54.Location = New System.Drawing.Point(23, 62)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(64, 15)
        Me.Label54.TabIndex = 2
        Me.Label54.Text = "Size : XXX"
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label55.ForeColor = System.Drawing.Color.Transparent
        Me.Label55.Location = New System.Drawing.Point(6, 41)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(98, 15)
        Me.Label55.TabIndex = 1
        Me.Label55.Text = "Starndard Room"
        '
        'Label56
        '
        Me.Label56.AutoSize = True
        Me.Label56.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label56.ForeColor = System.Drawing.Color.Transparent
        Me.Label56.Location = New System.Drawing.Point(24, 7)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(62, 31)
        Me.Label56.TabIndex = 0
        Me.Label56.Text = "101"
        '
        'Panel14
        '
        Me.Panel14.BackColor = System.Drawing.Color.ForestGreen
        Me.Panel14.Controls.Add(Me.Button14)
        Me.Panel14.Controls.Add(Me.Label57)
        Me.Panel14.Controls.Add(Me.Label58)
        Me.Panel14.Controls.Add(Me.Label59)
        Me.Panel14.Controls.Add(Me.Label60)
        Me.Panel14.Location = New System.Drawing.Point(479, 152)
        Me.Panel14.Name = "Panel14"
        Me.Panel14.Size = New System.Drawing.Size(113, 143)
        Me.Panel14.TabIndex = 13
        '
        'Button14
        '
        Me.Button14.Location = New System.Drawing.Point(7, 107)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(91, 30)
        Me.Button14.TabIndex = 4
        Me.Button14.Text = "Select"
        Me.Button14.UseVisualStyleBackColor = True
        '
        'Label57
        '
        Me.Label57.AutoSize = True
        Me.Label57.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label57.ForeColor = System.Drawing.Color.Transparent
        Me.Label57.Location = New System.Drawing.Point(18, 84)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(74, 15)
        Me.Label57.TabIndex = 3
        Me.Label57.Text = "2 Bedrooms"
        '
        'Label58
        '
        Me.Label58.AutoSize = True
        Me.Label58.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label58.ForeColor = System.Drawing.Color.Transparent
        Me.Label58.Location = New System.Drawing.Point(23, 62)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(64, 15)
        Me.Label58.TabIndex = 2
        Me.Label58.Text = "Size : XXX"
        '
        'Label59
        '
        Me.Label59.AutoSize = True
        Me.Label59.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label59.ForeColor = System.Drawing.Color.Transparent
        Me.Label59.Location = New System.Drawing.Point(6, 41)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(98, 15)
        Me.Label59.TabIndex = 1
        Me.Label59.Text = "Starndard Room"
        '
        'Label60
        '
        Me.Label60.AutoSize = True
        Me.Label60.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label60.ForeColor = System.Drawing.Color.Transparent
        Me.Label60.Location = New System.Drawing.Point(24, 7)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(62, 31)
        Me.Label60.TabIndex = 0
        Me.Label60.Text = "101"
        '
        'Panel15
        '
        Me.Panel15.BackColor = System.Drawing.Color.ForestGreen
        Me.Panel15.Controls.Add(Me.Button15)
        Me.Panel15.Controls.Add(Me.Label61)
        Me.Panel15.Controls.Add(Me.Label62)
        Me.Panel15.Controls.Add(Me.Label63)
        Me.Panel15.Controls.Add(Me.Label64)
        Me.Panel15.Location = New System.Drawing.Point(479, 301)
        Me.Panel15.Name = "Panel15"
        Me.Panel15.Size = New System.Drawing.Size(113, 143)
        Me.Panel15.TabIndex = 14
        '
        'Button15
        '
        Me.Button15.Location = New System.Drawing.Point(7, 107)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(91, 30)
        Me.Button15.TabIndex = 4
        Me.Button15.Text = "Select"
        Me.Button15.UseVisualStyleBackColor = True
        '
        'Label61
        '
        Me.Label61.AutoSize = True
        Me.Label61.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label61.ForeColor = System.Drawing.Color.Transparent
        Me.Label61.Location = New System.Drawing.Point(18, 84)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(74, 15)
        Me.Label61.TabIndex = 3
        Me.Label61.Text = "2 Bedrooms"
        '
        'Label62
        '
        Me.Label62.AutoSize = True
        Me.Label62.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label62.ForeColor = System.Drawing.Color.Transparent
        Me.Label62.Location = New System.Drawing.Point(23, 62)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(64, 15)
        Me.Label62.TabIndex = 2
        Me.Label62.Text = "Size : XXX"
        '
        'Label63
        '
        Me.Label63.AutoSize = True
        Me.Label63.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label63.ForeColor = System.Drawing.Color.Transparent
        Me.Label63.Location = New System.Drawing.Point(6, 41)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(98, 15)
        Me.Label63.TabIndex = 1
        Me.Label63.Text = "Starndard Room"
        '
        'Label64
        '
        Me.Label64.AutoSize = True
        Me.Label64.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label64.ForeColor = System.Drawing.Color.Transparent
        Me.Label64.Location = New System.Drawing.Point(24, 7)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(62, 31)
        Me.Label64.TabIndex = 0
        Me.Label64.Text = "101"
        '
        'Panel16
        '
        Me.Panel16.BackColor = System.Drawing.Color.ForestGreen
        Me.Panel16.Controls.Add(Me.Button16)
        Me.Panel16.Controls.Add(Me.Label65)
        Me.Panel16.Controls.Add(Me.Label66)
        Me.Panel16.Controls.Add(Me.Label67)
        Me.Panel16.Controls.Add(Me.Label68)
        Me.Panel16.Location = New System.Drawing.Point(598, 3)
        Me.Panel16.Name = "Panel16"
        Me.Panel16.Size = New System.Drawing.Size(113, 143)
        Me.Panel16.TabIndex = 15
        '
        'Button16
        '
        Me.Button16.Location = New System.Drawing.Point(7, 107)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(91, 30)
        Me.Button16.TabIndex = 4
        Me.Button16.Text = "Select"
        Me.Button16.UseVisualStyleBackColor = True
        '
        'Label65
        '
        Me.Label65.AutoSize = True
        Me.Label65.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label65.ForeColor = System.Drawing.Color.Transparent
        Me.Label65.Location = New System.Drawing.Point(18, 84)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(74, 15)
        Me.Label65.TabIndex = 3
        Me.Label65.Text = "2 Bedrooms"
        '
        'Label66
        '
        Me.Label66.AutoSize = True
        Me.Label66.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label66.ForeColor = System.Drawing.Color.Transparent
        Me.Label66.Location = New System.Drawing.Point(23, 62)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(64, 15)
        Me.Label66.TabIndex = 2
        Me.Label66.Text = "Size : XXX"
        '
        'Label67
        '
        Me.Label67.AutoSize = True
        Me.Label67.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label67.ForeColor = System.Drawing.Color.Transparent
        Me.Label67.Location = New System.Drawing.Point(6, 41)
        Me.Label67.Name = "Label67"
        Me.Label67.Size = New System.Drawing.Size(98, 15)
        Me.Label67.TabIndex = 1
        Me.Label67.Text = "Starndard Room"
        '
        'Label68
        '
        Me.Label68.AutoSize = True
        Me.Label68.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label68.ForeColor = System.Drawing.Color.Transparent
        Me.Label68.Location = New System.Drawing.Point(24, 7)
        Me.Label68.Name = "Label68"
        Me.Label68.Size = New System.Drawing.Size(62, 31)
        Me.Label68.TabIndex = 0
        Me.Label68.Text = "101"
        '
        'Panel17
        '
        Me.Panel17.BackColor = System.Drawing.Color.ForestGreen
        Me.Panel17.Controls.Add(Me.Button17)
        Me.Panel17.Controls.Add(Me.Label69)
        Me.Panel17.Controls.Add(Me.Label70)
        Me.Panel17.Controls.Add(Me.Label71)
        Me.Panel17.Controls.Add(Me.Label72)
        Me.Panel17.Location = New System.Drawing.Point(598, 152)
        Me.Panel17.Name = "Panel17"
        Me.Panel17.Size = New System.Drawing.Size(113, 143)
        Me.Panel17.TabIndex = 16
        '
        'Button17
        '
        Me.Button17.Location = New System.Drawing.Point(7, 107)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(91, 30)
        Me.Button17.TabIndex = 4
        Me.Button17.Text = "Select"
        Me.Button17.UseVisualStyleBackColor = True
        '
        'Label69
        '
        Me.Label69.AutoSize = True
        Me.Label69.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label69.ForeColor = System.Drawing.Color.Transparent
        Me.Label69.Location = New System.Drawing.Point(18, 84)
        Me.Label69.Name = "Label69"
        Me.Label69.Size = New System.Drawing.Size(74, 15)
        Me.Label69.TabIndex = 3
        Me.Label69.Text = "2 Bedrooms"
        '
        'Label70
        '
        Me.Label70.AutoSize = True
        Me.Label70.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label70.ForeColor = System.Drawing.Color.Transparent
        Me.Label70.Location = New System.Drawing.Point(23, 62)
        Me.Label70.Name = "Label70"
        Me.Label70.Size = New System.Drawing.Size(64, 15)
        Me.Label70.TabIndex = 2
        Me.Label70.Text = "Size : XXX"
        '
        'Label71
        '
        Me.Label71.AutoSize = True
        Me.Label71.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label71.ForeColor = System.Drawing.Color.Transparent
        Me.Label71.Location = New System.Drawing.Point(6, 41)
        Me.Label71.Name = "Label71"
        Me.Label71.Size = New System.Drawing.Size(98, 15)
        Me.Label71.TabIndex = 1
        Me.Label71.Text = "Starndard Room"
        '
        'Label72
        '
        Me.Label72.AutoSize = True
        Me.Label72.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label72.ForeColor = System.Drawing.Color.Transparent
        Me.Label72.Location = New System.Drawing.Point(24, 7)
        Me.Label72.Name = "Label72"
        Me.Label72.Size = New System.Drawing.Size(62, 31)
        Me.Label72.TabIndex = 0
        Me.Label72.Text = "101"
        '
        'Panel18
        '
        Me.Panel18.BackColor = System.Drawing.Color.ForestGreen
        Me.Panel18.Controls.Add(Me.Button18)
        Me.Panel18.Controls.Add(Me.Label73)
        Me.Panel18.Controls.Add(Me.Label74)
        Me.Panel18.Controls.Add(Me.Label75)
        Me.Panel18.Controls.Add(Me.Label76)
        Me.Panel18.Location = New System.Drawing.Point(598, 301)
        Me.Panel18.Name = "Panel18"
        Me.Panel18.Size = New System.Drawing.Size(113, 143)
        Me.Panel18.TabIndex = 17
        '
        'Button18
        '
        Me.Button18.Location = New System.Drawing.Point(7, 107)
        Me.Button18.Name = "Button18"
        Me.Button18.Size = New System.Drawing.Size(91, 30)
        Me.Button18.TabIndex = 4
        Me.Button18.Text = "Select"
        Me.Button18.UseVisualStyleBackColor = True
        '
        'Label73
        '
        Me.Label73.AutoSize = True
        Me.Label73.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label73.ForeColor = System.Drawing.Color.Transparent
        Me.Label73.Location = New System.Drawing.Point(18, 84)
        Me.Label73.Name = "Label73"
        Me.Label73.Size = New System.Drawing.Size(74, 15)
        Me.Label73.TabIndex = 3
        Me.Label73.Text = "2 Bedrooms"
        '
        'Label74
        '
        Me.Label74.AutoSize = True
        Me.Label74.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label74.ForeColor = System.Drawing.Color.Transparent
        Me.Label74.Location = New System.Drawing.Point(23, 62)
        Me.Label74.Name = "Label74"
        Me.Label74.Size = New System.Drawing.Size(64, 15)
        Me.Label74.TabIndex = 2
        Me.Label74.Text = "Size : XXX"
        '
        'Label75
        '
        Me.Label75.AutoSize = True
        Me.Label75.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label75.ForeColor = System.Drawing.Color.Transparent
        Me.Label75.Location = New System.Drawing.Point(6, 41)
        Me.Label75.Name = "Label75"
        Me.Label75.Size = New System.Drawing.Size(98, 15)
        Me.Label75.TabIndex = 1
        Me.Label75.Text = "Starndard Room"
        '
        'Label76
        '
        Me.Label76.AutoSize = True
        Me.Label76.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label76.ForeColor = System.Drawing.Color.Transparent
        Me.Label76.Location = New System.Drawing.Point(24, 7)
        Me.Label76.Name = "Label76"
        Me.Label76.Size = New System.Drawing.Size(62, 31)
        Me.Label76.TabIndex = 0
        Me.Label76.Text = "101"
        '
        'Panel20
        '
        Me.Panel20.BackColor = System.Drawing.Color.ForestGreen
        Me.Panel20.Controls.Add(Me.Button19)
        Me.Panel20.Controls.Add(Me.Label77)
        Me.Panel20.Controls.Add(Me.Label78)
        Me.Panel20.Controls.Add(Me.Label79)
        Me.Panel20.Controls.Add(Me.Label80)
        Me.Panel20.Location = New System.Drawing.Point(717, 3)
        Me.Panel20.Name = "Panel20"
        Me.Panel20.Size = New System.Drawing.Size(113, 143)
        Me.Panel20.TabIndex = 18
        '
        'Button19
        '
        Me.Button19.Location = New System.Drawing.Point(7, 107)
        Me.Button19.Name = "Button19"
        Me.Button19.Size = New System.Drawing.Size(91, 30)
        Me.Button19.TabIndex = 4
        Me.Button19.Text = "Select"
        Me.Button19.UseVisualStyleBackColor = True
        '
        'Label77
        '
        Me.Label77.AutoSize = True
        Me.Label77.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label77.ForeColor = System.Drawing.Color.Transparent
        Me.Label77.Location = New System.Drawing.Point(18, 84)
        Me.Label77.Name = "Label77"
        Me.Label77.Size = New System.Drawing.Size(74, 15)
        Me.Label77.TabIndex = 3
        Me.Label77.Text = "2 Bedrooms"
        '
        'Label78
        '
        Me.Label78.AutoSize = True
        Me.Label78.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label78.ForeColor = System.Drawing.Color.Transparent
        Me.Label78.Location = New System.Drawing.Point(23, 62)
        Me.Label78.Name = "Label78"
        Me.Label78.Size = New System.Drawing.Size(64, 15)
        Me.Label78.TabIndex = 2
        Me.Label78.Text = "Size : XXX"
        '
        'Label79
        '
        Me.Label79.AutoSize = True
        Me.Label79.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label79.ForeColor = System.Drawing.Color.Transparent
        Me.Label79.Location = New System.Drawing.Point(6, 41)
        Me.Label79.Name = "Label79"
        Me.Label79.Size = New System.Drawing.Size(98, 15)
        Me.Label79.TabIndex = 1
        Me.Label79.Text = "Starndard Room"
        '
        'Label80
        '
        Me.Label80.AutoSize = True
        Me.Label80.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label80.ForeColor = System.Drawing.Color.Transparent
        Me.Label80.Location = New System.Drawing.Point(24, 7)
        Me.Label80.Name = "Label80"
        Me.Label80.Size = New System.Drawing.Size(62, 31)
        Me.Label80.TabIndex = 0
        Me.Label80.Text = "101"
        '
        'Panel21
        '
        Me.Panel21.BackColor = System.Drawing.Color.ForestGreen
        Me.Panel21.Controls.Add(Me.Button20)
        Me.Panel21.Controls.Add(Me.Label81)
        Me.Panel21.Controls.Add(Me.Label82)
        Me.Panel21.Controls.Add(Me.Label83)
        Me.Panel21.Controls.Add(Me.Label84)
        Me.Panel21.Location = New System.Drawing.Point(717, 152)
        Me.Panel21.Name = "Panel21"
        Me.Panel21.Size = New System.Drawing.Size(113, 143)
        Me.Panel21.TabIndex = 19
        '
        'Button20
        '
        Me.Button20.Location = New System.Drawing.Point(7, 107)
        Me.Button20.Name = "Button20"
        Me.Button20.Size = New System.Drawing.Size(91, 30)
        Me.Button20.TabIndex = 4
        Me.Button20.Text = "Select"
        Me.Button20.UseVisualStyleBackColor = True
        '
        'Label81
        '
        Me.Label81.AutoSize = True
        Me.Label81.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label81.ForeColor = System.Drawing.Color.Transparent
        Me.Label81.Location = New System.Drawing.Point(18, 84)
        Me.Label81.Name = "Label81"
        Me.Label81.Size = New System.Drawing.Size(74, 15)
        Me.Label81.TabIndex = 3
        Me.Label81.Text = "2 Bedrooms"
        '
        'Label82
        '
        Me.Label82.AutoSize = True
        Me.Label82.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label82.ForeColor = System.Drawing.Color.Transparent
        Me.Label82.Location = New System.Drawing.Point(23, 62)
        Me.Label82.Name = "Label82"
        Me.Label82.Size = New System.Drawing.Size(64, 15)
        Me.Label82.TabIndex = 2
        Me.Label82.Text = "Size : XXX"
        '
        'Label83
        '
        Me.Label83.AutoSize = True
        Me.Label83.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label83.ForeColor = System.Drawing.Color.Transparent
        Me.Label83.Location = New System.Drawing.Point(6, 41)
        Me.Label83.Name = "Label83"
        Me.Label83.Size = New System.Drawing.Size(98, 15)
        Me.Label83.TabIndex = 1
        Me.Label83.Text = "Starndard Room"
        '
        'Label84
        '
        Me.Label84.AutoSize = True
        Me.Label84.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label84.ForeColor = System.Drawing.Color.Transparent
        Me.Label84.Location = New System.Drawing.Point(24, 7)
        Me.Label84.Name = "Label84"
        Me.Label84.Size = New System.Drawing.Size(62, 31)
        Me.Label84.TabIndex = 0
        Me.Label84.Text = "101"
        '
        'Panel22
        '
        Me.Panel22.BackColor = System.Drawing.Color.ForestGreen
        Me.Panel22.Controls.Add(Me.Button21)
        Me.Panel22.Controls.Add(Me.Label85)
        Me.Panel22.Controls.Add(Me.Label86)
        Me.Panel22.Controls.Add(Me.Label87)
        Me.Panel22.Controls.Add(Me.Label88)
        Me.Panel22.Location = New System.Drawing.Point(717, 301)
        Me.Panel22.Name = "Panel22"
        Me.Panel22.Size = New System.Drawing.Size(113, 143)
        Me.Panel22.TabIndex = 20
        '
        'Button21
        '
        Me.Button21.Location = New System.Drawing.Point(7, 107)
        Me.Button21.Name = "Button21"
        Me.Button21.Size = New System.Drawing.Size(91, 30)
        Me.Button21.TabIndex = 4
        Me.Button21.Text = "Select"
        Me.Button21.UseVisualStyleBackColor = True
        '
        'Label85
        '
        Me.Label85.AutoSize = True
        Me.Label85.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label85.ForeColor = System.Drawing.Color.Transparent
        Me.Label85.Location = New System.Drawing.Point(18, 84)
        Me.Label85.Name = "Label85"
        Me.Label85.Size = New System.Drawing.Size(74, 15)
        Me.Label85.TabIndex = 3
        Me.Label85.Text = "2 Bedrooms"
        '
        'Label86
        '
        Me.Label86.AutoSize = True
        Me.Label86.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label86.ForeColor = System.Drawing.Color.Transparent
        Me.Label86.Location = New System.Drawing.Point(23, 62)
        Me.Label86.Name = "Label86"
        Me.Label86.Size = New System.Drawing.Size(64, 15)
        Me.Label86.TabIndex = 2
        Me.Label86.Text = "Size : XXX"
        '
        'Label87
        '
        Me.Label87.AutoSize = True
        Me.Label87.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label87.ForeColor = System.Drawing.Color.Transparent
        Me.Label87.Location = New System.Drawing.Point(6, 41)
        Me.Label87.Name = "Label87"
        Me.Label87.Size = New System.Drawing.Size(98, 15)
        Me.Label87.TabIndex = 1
        Me.Label87.Text = "Starndard Room"
        '
        'Label88
        '
        Me.Label88.AutoSize = True
        Me.Label88.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label88.ForeColor = System.Drawing.Color.Transparent
        Me.Label88.Location = New System.Drawing.Point(24, 7)
        Me.Label88.Name = "Label88"
        Me.Label88.Size = New System.Drawing.Size(62, 31)
        Me.Label88.TabIndex = 0
        Me.Label88.Text = "101"
        '
        'Panel23
        '
        Me.Panel23.BackColor = System.Drawing.Color.Red
        Me.Panel23.Controls.Add(Me.Button22)
        Me.Panel23.Controls.Add(Me.Label89)
        Me.Panel23.Controls.Add(Me.Label90)
        Me.Panel23.Controls.Add(Me.Label91)
        Me.Panel23.Controls.Add(Me.Label92)
        Me.Panel23.Location = New System.Drawing.Point(836, 3)
        Me.Panel23.Name = "Panel23"
        Me.Panel23.Size = New System.Drawing.Size(113, 143)
        Me.Panel23.TabIndex = 21
        '
        'Button22
        '
        Me.Button22.Location = New System.Drawing.Point(7, 107)
        Me.Button22.Name = "Button22"
        Me.Button22.Size = New System.Drawing.Size(91, 30)
        Me.Button22.TabIndex = 4
        Me.Button22.Text = "Select"
        Me.Button22.UseVisualStyleBackColor = True
        '
        'Label89
        '
        Me.Label89.AutoSize = True
        Me.Label89.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label89.ForeColor = System.Drawing.Color.Transparent
        Me.Label89.Location = New System.Drawing.Point(18, 84)
        Me.Label89.Name = "Label89"
        Me.Label89.Size = New System.Drawing.Size(74, 15)
        Me.Label89.TabIndex = 3
        Me.Label89.Text = "2 Bedrooms"
        '
        'Label90
        '
        Me.Label90.AutoSize = True
        Me.Label90.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label90.ForeColor = System.Drawing.Color.Transparent
        Me.Label90.Location = New System.Drawing.Point(23, 62)
        Me.Label90.Name = "Label90"
        Me.Label90.Size = New System.Drawing.Size(64, 15)
        Me.Label90.TabIndex = 2
        Me.Label90.Text = "Size : XXX"
        '
        'Label91
        '
        Me.Label91.AutoSize = True
        Me.Label91.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label91.ForeColor = System.Drawing.Color.Transparent
        Me.Label91.Location = New System.Drawing.Point(6, 41)
        Me.Label91.Name = "Label91"
        Me.Label91.Size = New System.Drawing.Size(98, 15)
        Me.Label91.TabIndex = 1
        Me.Label91.Text = "Starndard Room"
        '
        'Label92
        '
        Me.Label92.AutoSize = True
        Me.Label92.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label92.ForeColor = System.Drawing.Color.Transparent
        Me.Label92.Location = New System.Drawing.Point(24, 7)
        Me.Label92.Name = "Label92"
        Me.Label92.Size = New System.Drawing.Size(62, 31)
        Me.Label92.TabIndex = 0
        Me.Label92.Text = "101"
        '
        'Panel24
        '
        Me.Panel24.BackColor = System.Drawing.Color.ForestGreen
        Me.Panel24.Controls.Add(Me.Button23)
        Me.Panel24.Controls.Add(Me.Label93)
        Me.Panel24.Controls.Add(Me.Label94)
        Me.Panel24.Controls.Add(Me.Label95)
        Me.Panel24.Controls.Add(Me.Label96)
        Me.Panel24.Location = New System.Drawing.Point(836, 152)
        Me.Panel24.Name = "Panel24"
        Me.Panel24.Size = New System.Drawing.Size(113, 143)
        Me.Panel24.TabIndex = 22
        '
        'Button23
        '
        Me.Button23.Location = New System.Drawing.Point(7, 107)
        Me.Button23.Name = "Button23"
        Me.Button23.Size = New System.Drawing.Size(91, 30)
        Me.Button23.TabIndex = 4
        Me.Button23.Text = "Select"
        Me.Button23.UseVisualStyleBackColor = True
        '
        'Label93
        '
        Me.Label93.AutoSize = True
        Me.Label93.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label93.ForeColor = System.Drawing.Color.Transparent
        Me.Label93.Location = New System.Drawing.Point(18, 84)
        Me.Label93.Name = "Label93"
        Me.Label93.Size = New System.Drawing.Size(74, 15)
        Me.Label93.TabIndex = 3
        Me.Label93.Text = "2 Bedrooms"
        '
        'Label94
        '
        Me.Label94.AutoSize = True
        Me.Label94.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label94.ForeColor = System.Drawing.Color.Transparent
        Me.Label94.Location = New System.Drawing.Point(23, 62)
        Me.Label94.Name = "Label94"
        Me.Label94.Size = New System.Drawing.Size(64, 15)
        Me.Label94.TabIndex = 2
        Me.Label94.Text = "Size : XXX"
        '
        'Label95
        '
        Me.Label95.AutoSize = True
        Me.Label95.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label95.ForeColor = System.Drawing.Color.Transparent
        Me.Label95.Location = New System.Drawing.Point(6, 41)
        Me.Label95.Name = "Label95"
        Me.Label95.Size = New System.Drawing.Size(98, 15)
        Me.Label95.TabIndex = 1
        Me.Label95.Text = "Starndard Room"
        '
        'Label96
        '
        Me.Label96.AutoSize = True
        Me.Label96.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label96.ForeColor = System.Drawing.Color.Transparent
        Me.Label96.Location = New System.Drawing.Point(24, 7)
        Me.Label96.Name = "Label96"
        Me.Label96.Size = New System.Drawing.Size(62, 31)
        Me.Label96.TabIndex = 0
        Me.Label96.Text = "101"
        '
        'Panel25
        '
        Me.Panel25.BackColor = System.Drawing.Color.Red
        Me.Panel25.Controls.Add(Me.Button24)
        Me.Panel25.Controls.Add(Me.Label97)
        Me.Panel25.Controls.Add(Me.Label98)
        Me.Panel25.Controls.Add(Me.Label99)
        Me.Panel25.Controls.Add(Me.Label100)
        Me.Panel25.Location = New System.Drawing.Point(836, 301)
        Me.Panel25.Name = "Panel25"
        Me.Panel25.Size = New System.Drawing.Size(113, 143)
        Me.Panel25.TabIndex = 23
        '
        'Button24
        '
        Me.Button24.Location = New System.Drawing.Point(7, 107)
        Me.Button24.Name = "Button24"
        Me.Button24.Size = New System.Drawing.Size(91, 30)
        Me.Button24.TabIndex = 4
        Me.Button24.Text = "Select"
        Me.Button24.UseVisualStyleBackColor = True
        '
        'Label97
        '
        Me.Label97.AutoSize = True
        Me.Label97.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label97.ForeColor = System.Drawing.Color.Transparent
        Me.Label97.Location = New System.Drawing.Point(18, 84)
        Me.Label97.Name = "Label97"
        Me.Label97.Size = New System.Drawing.Size(74, 15)
        Me.Label97.TabIndex = 3
        Me.Label97.Text = "2 Bedrooms"
        '
        'Label98
        '
        Me.Label98.AutoSize = True
        Me.Label98.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label98.ForeColor = System.Drawing.Color.Transparent
        Me.Label98.Location = New System.Drawing.Point(23, 62)
        Me.Label98.Name = "Label98"
        Me.Label98.Size = New System.Drawing.Size(64, 15)
        Me.Label98.TabIndex = 2
        Me.Label98.Text = "Size : XXX"
        '
        'Label99
        '
        Me.Label99.AutoSize = True
        Me.Label99.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label99.ForeColor = System.Drawing.Color.Transparent
        Me.Label99.Location = New System.Drawing.Point(6, 41)
        Me.Label99.Name = "Label99"
        Me.Label99.Size = New System.Drawing.Size(98, 15)
        Me.Label99.TabIndex = 1
        Me.Label99.Text = "Starndard Room"
        '
        'Label100
        '
        Me.Label100.AutoSize = True
        Me.Label100.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label100.ForeColor = System.Drawing.Color.Transparent
        Me.Label100.Location = New System.Drawing.Point(24, 7)
        Me.Label100.Name = "Label100"
        Me.Label100.Size = New System.Drawing.Size(62, 31)
        Me.Label100.TabIndex = 0
        Me.Label100.Text = "101"
        '
        'Panel26
        '
        Me.Panel26.BackColor = System.Drawing.Color.ForestGreen
        Me.Panel26.Controls.Add(Me.Button25)
        Me.Panel26.Controls.Add(Me.Label101)
        Me.Panel26.Controls.Add(Me.Label102)
        Me.Panel26.Controls.Add(Me.Label103)
        Me.Panel26.Controls.Add(Me.Label104)
        Me.Panel26.Location = New System.Drawing.Point(955, 3)
        Me.Panel26.Name = "Panel26"
        Me.Panel26.Size = New System.Drawing.Size(113, 143)
        Me.Panel26.TabIndex = 24
        '
        'Button25
        '
        Me.Button25.Location = New System.Drawing.Point(7, 107)
        Me.Button25.Name = "Button25"
        Me.Button25.Size = New System.Drawing.Size(91, 30)
        Me.Button25.TabIndex = 4
        Me.Button25.Text = "Select"
        Me.Button25.UseVisualStyleBackColor = True
        '
        'Label101
        '
        Me.Label101.AutoSize = True
        Me.Label101.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label101.ForeColor = System.Drawing.Color.Transparent
        Me.Label101.Location = New System.Drawing.Point(18, 84)
        Me.Label101.Name = "Label101"
        Me.Label101.Size = New System.Drawing.Size(74, 15)
        Me.Label101.TabIndex = 3
        Me.Label101.Text = "2 Bedrooms"
        '
        'Label102
        '
        Me.Label102.AutoSize = True
        Me.Label102.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label102.ForeColor = System.Drawing.Color.Transparent
        Me.Label102.Location = New System.Drawing.Point(23, 62)
        Me.Label102.Name = "Label102"
        Me.Label102.Size = New System.Drawing.Size(64, 15)
        Me.Label102.TabIndex = 2
        Me.Label102.Text = "Size : XXX"
        '
        'Label103
        '
        Me.Label103.AutoSize = True
        Me.Label103.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label103.ForeColor = System.Drawing.Color.Transparent
        Me.Label103.Location = New System.Drawing.Point(6, 41)
        Me.Label103.Name = "Label103"
        Me.Label103.Size = New System.Drawing.Size(98, 15)
        Me.Label103.TabIndex = 1
        Me.Label103.Text = "Starndard Room"
        '
        'Label104
        '
        Me.Label104.AutoSize = True
        Me.Label104.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label104.ForeColor = System.Drawing.Color.Transparent
        Me.Label104.Location = New System.Drawing.Point(24, 7)
        Me.Label104.Name = "Label104"
        Me.Label104.Size = New System.Drawing.Size(62, 31)
        Me.Label104.TabIndex = 0
        Me.Label104.Text = "101"
        '
        'Panel27
        '
        Me.Panel27.BackColor = System.Drawing.Color.ForestGreen
        Me.Panel27.Controls.Add(Me.Button26)
        Me.Panel27.Controls.Add(Me.Label105)
        Me.Panel27.Controls.Add(Me.Label106)
        Me.Panel27.Controls.Add(Me.Label107)
        Me.Panel27.Controls.Add(Me.Label108)
        Me.Panel27.Location = New System.Drawing.Point(955, 152)
        Me.Panel27.Name = "Panel27"
        Me.Panel27.Size = New System.Drawing.Size(113, 143)
        Me.Panel27.TabIndex = 25
        '
        'Button26
        '
        Me.Button26.Location = New System.Drawing.Point(7, 107)
        Me.Button26.Name = "Button26"
        Me.Button26.Size = New System.Drawing.Size(91, 30)
        Me.Button26.TabIndex = 4
        Me.Button26.Text = "Select"
        Me.Button26.UseVisualStyleBackColor = True
        '
        'Label105
        '
        Me.Label105.AutoSize = True
        Me.Label105.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label105.ForeColor = System.Drawing.Color.Transparent
        Me.Label105.Location = New System.Drawing.Point(18, 84)
        Me.Label105.Name = "Label105"
        Me.Label105.Size = New System.Drawing.Size(74, 15)
        Me.Label105.TabIndex = 3
        Me.Label105.Text = "2 Bedrooms"
        '
        'Label106
        '
        Me.Label106.AutoSize = True
        Me.Label106.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label106.ForeColor = System.Drawing.Color.Transparent
        Me.Label106.Location = New System.Drawing.Point(23, 62)
        Me.Label106.Name = "Label106"
        Me.Label106.Size = New System.Drawing.Size(64, 15)
        Me.Label106.TabIndex = 2
        Me.Label106.Text = "Size : XXX"
        '
        'Label107
        '
        Me.Label107.AutoSize = True
        Me.Label107.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label107.ForeColor = System.Drawing.Color.Transparent
        Me.Label107.Location = New System.Drawing.Point(6, 41)
        Me.Label107.Name = "Label107"
        Me.Label107.Size = New System.Drawing.Size(98, 15)
        Me.Label107.TabIndex = 1
        Me.Label107.Text = "Starndard Room"
        '
        'Label108
        '
        Me.Label108.AutoSize = True
        Me.Label108.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label108.ForeColor = System.Drawing.Color.Transparent
        Me.Label108.Location = New System.Drawing.Point(24, 7)
        Me.Label108.Name = "Label108"
        Me.Label108.Size = New System.Drawing.Size(62, 31)
        Me.Label108.TabIndex = 0
        Me.Label108.Text = "101"
        '
        'Panel28
        '
        Me.Panel28.BackColor = System.Drawing.Color.ForestGreen
        Me.Panel28.Controls.Add(Me.Button27)
        Me.Panel28.Controls.Add(Me.Label109)
        Me.Panel28.Controls.Add(Me.Label110)
        Me.Panel28.Controls.Add(Me.Label111)
        Me.Panel28.Controls.Add(Me.Label112)
        Me.Panel28.Location = New System.Drawing.Point(955, 301)
        Me.Panel28.Name = "Panel28"
        Me.Panel28.Size = New System.Drawing.Size(113, 143)
        Me.Panel28.TabIndex = 26
        '
        'Button27
        '
        Me.Button27.Location = New System.Drawing.Point(7, 107)
        Me.Button27.Name = "Button27"
        Me.Button27.Size = New System.Drawing.Size(91, 30)
        Me.Button27.TabIndex = 4
        Me.Button27.Text = "Select"
        Me.Button27.UseVisualStyleBackColor = True
        '
        'Label109
        '
        Me.Label109.AutoSize = True
        Me.Label109.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label109.ForeColor = System.Drawing.Color.Transparent
        Me.Label109.Location = New System.Drawing.Point(18, 84)
        Me.Label109.Name = "Label109"
        Me.Label109.Size = New System.Drawing.Size(74, 15)
        Me.Label109.TabIndex = 3
        Me.Label109.Text = "2 Bedrooms"
        '
        'Label110
        '
        Me.Label110.AutoSize = True
        Me.Label110.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label110.ForeColor = System.Drawing.Color.Transparent
        Me.Label110.Location = New System.Drawing.Point(23, 62)
        Me.Label110.Name = "Label110"
        Me.Label110.Size = New System.Drawing.Size(64, 15)
        Me.Label110.TabIndex = 2
        Me.Label110.Text = "Size : XXX"
        '
        'Label111
        '
        Me.Label111.AutoSize = True
        Me.Label111.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label111.ForeColor = System.Drawing.Color.Transparent
        Me.Label111.Location = New System.Drawing.Point(6, 41)
        Me.Label111.Name = "Label111"
        Me.Label111.Size = New System.Drawing.Size(98, 15)
        Me.Label111.TabIndex = 1
        Me.Label111.Text = "Starndard Room"
        '
        'Label112
        '
        Me.Label112.AutoSize = True
        Me.Label112.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label112.ForeColor = System.Drawing.Color.Transparent
        Me.Label112.Location = New System.Drawing.Point(24, 7)
        Me.Label112.Name = "Label112"
        Me.Label112.Size = New System.Drawing.Size(62, 31)
        Me.Label112.TabIndex = 0
        Me.Label112.Text = "101"
        '
        'Panel29
        '
        Me.Panel29.BackColor = System.Drawing.Color.ForestGreen
        Me.Panel29.Controls.Add(Me.Button28)
        Me.Panel29.Controls.Add(Me.Label113)
        Me.Panel29.Controls.Add(Me.Label114)
        Me.Panel29.Controls.Add(Me.Label115)
        Me.Panel29.Controls.Add(Me.Label116)
        Me.Panel29.Location = New System.Drawing.Point(1074, 3)
        Me.Panel29.Name = "Panel29"
        Me.Panel29.Size = New System.Drawing.Size(113, 143)
        Me.Panel29.TabIndex = 27
        '
        'Button28
        '
        Me.Button28.Location = New System.Drawing.Point(7, 107)
        Me.Button28.Name = "Button28"
        Me.Button28.Size = New System.Drawing.Size(91, 30)
        Me.Button28.TabIndex = 4
        Me.Button28.Text = "Select"
        Me.Button28.UseVisualStyleBackColor = True
        '
        'Label113
        '
        Me.Label113.AutoSize = True
        Me.Label113.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label113.ForeColor = System.Drawing.Color.Transparent
        Me.Label113.Location = New System.Drawing.Point(18, 84)
        Me.Label113.Name = "Label113"
        Me.Label113.Size = New System.Drawing.Size(74, 15)
        Me.Label113.TabIndex = 3
        Me.Label113.Text = "2 Bedrooms"
        '
        'Label114
        '
        Me.Label114.AutoSize = True
        Me.Label114.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label114.ForeColor = System.Drawing.Color.Transparent
        Me.Label114.Location = New System.Drawing.Point(23, 62)
        Me.Label114.Name = "Label114"
        Me.Label114.Size = New System.Drawing.Size(64, 15)
        Me.Label114.TabIndex = 2
        Me.Label114.Text = "Size : XXX"
        '
        'Label115
        '
        Me.Label115.AutoSize = True
        Me.Label115.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label115.ForeColor = System.Drawing.Color.Transparent
        Me.Label115.Location = New System.Drawing.Point(6, 41)
        Me.Label115.Name = "Label115"
        Me.Label115.Size = New System.Drawing.Size(98, 15)
        Me.Label115.TabIndex = 1
        Me.Label115.Text = "Starndard Room"
        '
        'Label116
        '
        Me.Label116.AutoSize = True
        Me.Label116.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label116.ForeColor = System.Drawing.Color.Transparent
        Me.Label116.Location = New System.Drawing.Point(24, 7)
        Me.Label116.Name = "Label116"
        Me.Label116.Size = New System.Drawing.Size(62, 31)
        Me.Label116.TabIndex = 0
        Me.Label116.Text = "101"
        '
        'Panel30
        '
        Me.Panel30.BackColor = System.Drawing.Color.ForestGreen
        Me.Panel30.Controls.Add(Me.Button29)
        Me.Panel30.Controls.Add(Me.Label117)
        Me.Panel30.Controls.Add(Me.Label118)
        Me.Panel30.Controls.Add(Me.Label119)
        Me.Panel30.Controls.Add(Me.Label120)
        Me.Panel30.Location = New System.Drawing.Point(1074, 152)
        Me.Panel30.Name = "Panel30"
        Me.Panel30.Size = New System.Drawing.Size(113, 143)
        Me.Panel30.TabIndex = 28
        '
        'Button29
        '
        Me.Button29.Location = New System.Drawing.Point(7, 107)
        Me.Button29.Name = "Button29"
        Me.Button29.Size = New System.Drawing.Size(91, 30)
        Me.Button29.TabIndex = 4
        Me.Button29.Text = "Select"
        Me.Button29.UseVisualStyleBackColor = True
        '
        'Label117
        '
        Me.Label117.AutoSize = True
        Me.Label117.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label117.ForeColor = System.Drawing.Color.Transparent
        Me.Label117.Location = New System.Drawing.Point(18, 84)
        Me.Label117.Name = "Label117"
        Me.Label117.Size = New System.Drawing.Size(74, 15)
        Me.Label117.TabIndex = 3
        Me.Label117.Text = "2 Bedrooms"
        '
        'Label118
        '
        Me.Label118.AutoSize = True
        Me.Label118.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label118.ForeColor = System.Drawing.Color.Transparent
        Me.Label118.Location = New System.Drawing.Point(23, 62)
        Me.Label118.Name = "Label118"
        Me.Label118.Size = New System.Drawing.Size(64, 15)
        Me.Label118.TabIndex = 2
        Me.Label118.Text = "Size : XXX"
        '
        'Label119
        '
        Me.Label119.AutoSize = True
        Me.Label119.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label119.ForeColor = System.Drawing.Color.Transparent
        Me.Label119.Location = New System.Drawing.Point(6, 41)
        Me.Label119.Name = "Label119"
        Me.Label119.Size = New System.Drawing.Size(98, 15)
        Me.Label119.TabIndex = 1
        Me.Label119.Text = "Starndard Room"
        '
        'Label120
        '
        Me.Label120.AutoSize = True
        Me.Label120.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label120.ForeColor = System.Drawing.Color.Transparent
        Me.Label120.Location = New System.Drawing.Point(24, 7)
        Me.Label120.Name = "Label120"
        Me.Label120.Size = New System.Drawing.Size(62, 31)
        Me.Label120.TabIndex = 0
        Me.Label120.Text = "101"
        '
        'Panel31
        '
        Me.Panel31.BackColor = System.Drawing.Color.ForestGreen
        Me.Panel31.Controls.Add(Me.Button30)
        Me.Panel31.Controls.Add(Me.Label121)
        Me.Panel31.Controls.Add(Me.Label122)
        Me.Panel31.Controls.Add(Me.Label123)
        Me.Panel31.Controls.Add(Me.Label124)
        Me.Panel31.Location = New System.Drawing.Point(1074, 301)
        Me.Panel31.Name = "Panel31"
        Me.Panel31.Size = New System.Drawing.Size(113, 143)
        Me.Panel31.TabIndex = 29
        '
        'Button30
        '
        Me.Button30.Location = New System.Drawing.Point(7, 107)
        Me.Button30.Name = "Button30"
        Me.Button30.Size = New System.Drawing.Size(91, 30)
        Me.Button30.TabIndex = 4
        Me.Button30.Text = "Select"
        Me.Button30.UseVisualStyleBackColor = True
        '
        'Label121
        '
        Me.Label121.AutoSize = True
        Me.Label121.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label121.ForeColor = System.Drawing.Color.Transparent
        Me.Label121.Location = New System.Drawing.Point(18, 84)
        Me.Label121.Name = "Label121"
        Me.Label121.Size = New System.Drawing.Size(74, 15)
        Me.Label121.TabIndex = 3
        Me.Label121.Text = "2 Bedrooms"
        '
        'Label122
        '
        Me.Label122.AutoSize = True
        Me.Label122.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label122.ForeColor = System.Drawing.Color.Transparent
        Me.Label122.Location = New System.Drawing.Point(23, 62)
        Me.Label122.Name = "Label122"
        Me.Label122.Size = New System.Drawing.Size(64, 15)
        Me.Label122.TabIndex = 2
        Me.Label122.Text = "Size : XXX"
        '
        'Label123
        '
        Me.Label123.AutoSize = True
        Me.Label123.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label123.ForeColor = System.Drawing.Color.Transparent
        Me.Label123.Location = New System.Drawing.Point(6, 41)
        Me.Label123.Name = "Label123"
        Me.Label123.Size = New System.Drawing.Size(98, 15)
        Me.Label123.TabIndex = 1
        Me.Label123.Text = "Starndard Room"
        '
        'Label124
        '
        Me.Label124.AutoSize = True
        Me.Label124.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label124.ForeColor = System.Drawing.Color.Transparent
        Me.Label124.Location = New System.Drawing.Point(24, 7)
        Me.Label124.Name = "Label124"
        Me.Label124.Size = New System.Drawing.Size(62, 31)
        Me.Label124.TabIndex = 0
        Me.Label124.Text = "101"
        '
        'Panel32
        '
        Me.Panel32.BackColor = System.Drawing.Color.ForestGreen
        Me.Panel32.Controls.Add(Me.Button31)
        Me.Panel32.Controls.Add(Me.Label125)
        Me.Panel32.Controls.Add(Me.Label126)
        Me.Panel32.Controls.Add(Me.Label127)
        Me.Panel32.Controls.Add(Me.Label128)
        Me.Panel32.Location = New System.Drawing.Point(1193, 3)
        Me.Panel32.Name = "Panel32"
        Me.Panel32.Size = New System.Drawing.Size(113, 143)
        Me.Panel32.TabIndex = 30
        '
        'Button31
        '
        Me.Button31.Location = New System.Drawing.Point(7, 107)
        Me.Button31.Name = "Button31"
        Me.Button31.Size = New System.Drawing.Size(91, 30)
        Me.Button31.TabIndex = 4
        Me.Button31.Text = "Select"
        Me.Button31.UseVisualStyleBackColor = True
        '
        'Label125
        '
        Me.Label125.AutoSize = True
        Me.Label125.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label125.ForeColor = System.Drawing.Color.Transparent
        Me.Label125.Location = New System.Drawing.Point(18, 84)
        Me.Label125.Name = "Label125"
        Me.Label125.Size = New System.Drawing.Size(74, 15)
        Me.Label125.TabIndex = 3
        Me.Label125.Text = "2 Bedrooms"
        '
        'Label126
        '
        Me.Label126.AutoSize = True
        Me.Label126.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label126.ForeColor = System.Drawing.Color.Transparent
        Me.Label126.Location = New System.Drawing.Point(23, 62)
        Me.Label126.Name = "Label126"
        Me.Label126.Size = New System.Drawing.Size(64, 15)
        Me.Label126.TabIndex = 2
        Me.Label126.Text = "Size : XXX"
        '
        'Label127
        '
        Me.Label127.AutoSize = True
        Me.Label127.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label127.ForeColor = System.Drawing.Color.Transparent
        Me.Label127.Location = New System.Drawing.Point(6, 41)
        Me.Label127.Name = "Label127"
        Me.Label127.Size = New System.Drawing.Size(98, 15)
        Me.Label127.TabIndex = 1
        Me.Label127.Text = "Starndard Room"
        '
        'Label128
        '
        Me.Label128.AutoSize = True
        Me.Label128.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label128.ForeColor = System.Drawing.Color.Transparent
        Me.Label128.Location = New System.Drawing.Point(24, 7)
        Me.Label128.Name = "Label128"
        Me.Label128.Size = New System.Drawing.Size(62, 31)
        Me.Label128.TabIndex = 0
        Me.Label128.Text = "101"
        '
        'Panel33
        '
        Me.Panel33.BackColor = System.Drawing.Color.ForestGreen
        Me.Panel33.Controls.Add(Me.Button32)
        Me.Panel33.Controls.Add(Me.Label129)
        Me.Panel33.Controls.Add(Me.Label130)
        Me.Panel33.Controls.Add(Me.Label131)
        Me.Panel33.Controls.Add(Me.Label132)
        Me.Panel33.Location = New System.Drawing.Point(1193, 152)
        Me.Panel33.Name = "Panel33"
        Me.Panel33.Size = New System.Drawing.Size(113, 143)
        Me.Panel33.TabIndex = 31
        '
        'Button32
        '
        Me.Button32.Location = New System.Drawing.Point(7, 107)
        Me.Button32.Name = "Button32"
        Me.Button32.Size = New System.Drawing.Size(91, 30)
        Me.Button32.TabIndex = 4
        Me.Button32.Text = "Select"
        Me.Button32.UseVisualStyleBackColor = True
        '
        'Label129
        '
        Me.Label129.AutoSize = True
        Me.Label129.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label129.ForeColor = System.Drawing.Color.Transparent
        Me.Label129.Location = New System.Drawing.Point(18, 84)
        Me.Label129.Name = "Label129"
        Me.Label129.Size = New System.Drawing.Size(74, 15)
        Me.Label129.TabIndex = 3
        Me.Label129.Text = "2 Bedrooms"
        '
        'Label130
        '
        Me.Label130.AutoSize = True
        Me.Label130.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label130.ForeColor = System.Drawing.Color.Transparent
        Me.Label130.Location = New System.Drawing.Point(23, 62)
        Me.Label130.Name = "Label130"
        Me.Label130.Size = New System.Drawing.Size(64, 15)
        Me.Label130.TabIndex = 2
        Me.Label130.Text = "Size : XXX"
        '
        'Label131
        '
        Me.Label131.AutoSize = True
        Me.Label131.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label131.ForeColor = System.Drawing.Color.Transparent
        Me.Label131.Location = New System.Drawing.Point(6, 41)
        Me.Label131.Name = "Label131"
        Me.Label131.Size = New System.Drawing.Size(98, 15)
        Me.Label131.TabIndex = 1
        Me.Label131.Text = "Starndard Room"
        '
        'Label132
        '
        Me.Label132.AutoSize = True
        Me.Label132.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label132.ForeColor = System.Drawing.Color.Transparent
        Me.Label132.Location = New System.Drawing.Point(24, 7)
        Me.Label132.Name = "Label132"
        Me.Label132.Size = New System.Drawing.Size(62, 31)
        Me.Label132.TabIndex = 0
        Me.Label132.Text = "101"
        '
        'MaterialTabControl1
        '
        Me.MaterialTabControl1.Controls.Add(Me.TabPage1)
        Me.MaterialTabControl1.Controls.Add(Me.TabPage2)
        Me.MaterialTabControl1.Controls.Add(Me.TabPage3)
        Me.MaterialTabControl1.Depth = 0
        Me.MaterialTabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MaterialTabControl1.Location = New System.Drawing.Point(20, 183)
        Me.MaterialTabControl1.MouseState = MaterialSkin.MouseState.HOVER
        Me.MaterialTabControl1.Name = "MaterialTabControl1"
        Me.MaterialTabControl1.SelectedIndex = 0
        Me.MaterialTabControl1.Size = New System.Drawing.Size(973, 544)
        Me.MaterialTabControl1.TabIndex = 2
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.Label136)
        Me.TabPage3.Controls.Add(Me.DataGridView2)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(965, 518)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Room  Service"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'MaterialTabSelector1
        '
        Me.MaterialTabSelector1.BaseTabControl = Me.MaterialTabControl1
        Me.MaterialTabSelector1.Depth = 0
        Me.MaterialTabSelector1.Dock = System.Windows.Forms.DockStyle.Top
        Me.MaterialTabSelector1.Location = New System.Drawing.Point(20, 160)
        Me.MaterialTabSelector1.MouseState = MaterialSkin.MouseState.HOVER
        Me.MaterialTabSelector1.Name = "MaterialTabSelector1"
        Me.MaterialTabSelector1.Size = New System.Drawing.Size(973, 23)
        Me.MaterialTabSelector1.TabIndex = 1
        Me.MaterialTabSelector1.Text = "MaterialTabSelector1"
        '
        'Panel19
        '
        Me.Panel19.BackColor = System.Drawing.Color.WhiteSmoke
        Me.Panel19.Controls.Add(Me.TextBox3)
        Me.Panel19.Controls.Add(Me.Label134)
        Me.Panel19.Controls.Add(Me.TextBox1)
        Me.Panel19.Controls.Add(Me.Label133)
        Me.Panel19.Controls.Add(Me.MaterialRaisedButton1)
        Me.Panel19.Controls.Add(Me.PictureBox1)
        Me.Panel19.Controls.Add(Me.Label2)
        Me.Panel19.Controls.Add(Me.MetroDateTime1)
        Me.Panel19.Controls.Add(Me.TextBox2)
        Me.Panel19.Controls.Add(Me.Label7)
        Me.Panel19.Controls.Add(Me.Label1)
        Me.Panel19.Controls.Add(Me.Label12)
        Me.Panel19.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel19.Location = New System.Drawing.Point(20, 60)
        Me.Panel19.Name = "Panel19"
        Me.Panel19.Size = New System.Drawing.Size(973, 100)
        Me.Panel19.TabIndex = 0
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Copperplate Gothic Bold", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(8, 20)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(105, 14)
        Me.Label2.TabIndex = 32
        Me.Label2.Text = "Room Search :"
        '
        'MetroDateTime1
        '
        Me.MetroDateTime1.Location = New System.Drawing.Point(114, 12)
        Me.MetroDateTime1.MinimumSize = New System.Drawing.Size(0, 29)
        Me.MetroDateTime1.Name = "MetroDateTime1"
        Me.MetroDateTime1.Size = New System.Drawing.Size(217, 29)
        Me.MetroDateTime1.TabIndex = 31
        '
        'TextBox2
        '
        Me.TextBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox2.Location = New System.Drawing.Point(446, 14)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(222, 26)
        Me.TextBox2.TabIndex = 30
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Copperplate Gothic Bold", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(337, 19)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(107, 14)
        Me.Label7.TabIndex = 29
        Me.Label7.Text = "Guest Search :"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Copperplate Gothic Bold", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(733, 19)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(234, 14)
        Me.Label1.TabIndex = 28
        Me.Label1.Text = "November 12/12/2020 12:00AM"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Copperplate Gothic Bold", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(689, 19)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(47, 14)
        Me.Label12.TabIndex = 27
        Me.Label12.Text = "Date :"
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1, Me.ToolStripStatusLabel2, Me.ToolStripStatusLabel3, Me.ToolStripStatusLabel4, Me.ToolStripStatusLabel5})
        Me.StatusStrip1.Location = New System.Drawing.Point(20, 705)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(973, 22)
        Me.StatusStrip1.TabIndex = 3
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(126, 17)
        Me.ToolStripStatusLabel1.Text = "Total Occupied Rooms"
        '
        'ToolStripStatusLabel2
        '
        Me.ToolStripStatusLabel2.Name = "ToolStripStatusLabel2"
        Me.ToolStripStatusLabel2.Size = New System.Drawing.Size(19, 17)
        Me.ToolStripStatusLabel2.Text = "12"
        '
        'ToolStripStatusLabel3
        '
        Me.ToolStripStatusLabel3.Name = "ToolStripStatusLabel3"
        Me.ToolStripStatusLabel3.Size = New System.Drawing.Size(97, 17)
        Me.ToolStripStatusLabel3.Text = "Total Free Rooms"
        '
        'ToolStripStatusLabel4
        '
        Me.ToolStripStatusLabel4.Name = "ToolStripStatusLabel4"
        Me.ToolStripStatusLabel4.Size = New System.Drawing.Size(19, 17)
        Me.ToolStripStatusLabel4.Text = "20"
        '
        'ToolStripStatusLabel5
        '
        Me.ToolStripStatusLabel5.Name = "ToolStripStatusLabel5"
        Me.ToolStripStatusLabel5.Size = New System.Drawing.Size(0, 17)
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.LightGray
        Me.PictureBox1.Location = New System.Drawing.Point(746, 36)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(117, 58)
        Me.PictureBox1.TabIndex = 33
        Me.PictureBox1.TabStop = False
        '
        'MaterialRaisedButton1
        '
        Me.MaterialRaisedButton1.Depth = 0
        Me.MaterialRaisedButton1.Location = New System.Drawing.Point(869, 69)
        Me.MaterialRaisedButton1.MouseState = MaterialSkin.MouseState.HOVER
        Me.MaterialRaisedButton1.Name = "MaterialRaisedButton1"
        Me.MaterialRaisedButton1.Primary = True
        Me.MaterialRaisedButton1.Size = New System.Drawing.Size(91, 25)
        Me.MaterialRaisedButton1.TabIndex = 41
        Me.MaterialRaisedButton1.Text = "View Large"
        Me.MaterialRaisedButton1.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(114, 48)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(217, 26)
        Me.TextBox1.TabIndex = 43
        '
        'Label133
        '
        Me.Label133.AutoSize = True
        Me.Label133.Font = New System.Drawing.Font("Copperplate Gothic Bold", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label133.Location = New System.Drawing.Point(33, 56)
        Me.Label133.Name = "Label133"
        Me.Label133.Size = New System.Drawing.Size(74, 14)
        Me.Label133.TabIndex = 42
        Me.Label133.Text = "Room No :"
        '
        'TextBox3
        '
        Me.TextBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox3.Location = New System.Drawing.Point(507, 51)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(161, 26)
        Me.TextBox3.TabIndex = 45
        '
        'Label134
        '
        Me.Label134.AutoSize = True
        Me.Label134.Font = New System.Drawing.Font("Copperplate Gothic Bold", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label134.Location = New System.Drawing.Point(349, 56)
        Me.Label134.Name = "Label134"
        Me.Label134.Size = New System.Drawing.Size(154, 14)
        Me.Label134.TabIndex = 44
        Me.Label134.Text = " Search by Category :"
        '
        'DataGridView1
        '
        Me.DataGridView1.BackgroundColor = System.Drawing.Color.WhiteSmoke
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.roomno, Me.Roomasdfdas, Me.RoomStatusss, Me.Peopleasdf, Me.guestname, Me.contactno, Me.noofpeople, Me.CheckIN, Me.Checkoutdate, Me.RoomService, Me.KitchenService})
        Me.DataGridView1.Location = New System.Drawing.Point(18, 53)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(925, 420)
        Me.DataGridView1.TabIndex = 0
        '
        'roomno
        '
        Me.roomno.HeaderText = "Room No"
        Me.roomno.Name = "roomno"
        '
        'Roomasdfdas
        '
        Me.Roomasdfdas.HeaderText = "Room Type"
        Me.Roomasdfdas.Name = "Roomasdfdas"
        '
        'RoomStatusss
        '
        Me.RoomStatusss.HeaderText = "Room Satus"
        Me.RoomStatusss.Name = "RoomStatusss"
        '
        'Peopleasdf
        '
        Me.Peopleasdf.HeaderText = "Guest No"
        Me.Peopleasdf.Name = "Peopleasdf"
        '
        'guestname
        '
        Me.guestname.HeaderText = "Guest Name"
        Me.guestname.Name = "guestname"
        '
        'contactno
        '
        Me.contactno.HeaderText = "Contact No"
        Me.contactno.Name = "contactno"
        '
        'noofpeople
        '
        Me.noofpeople.HeaderText = "No of Guest"
        Me.noofpeople.Name = "noofpeople"
        '
        'CheckIN
        '
        Me.CheckIN.HeaderText = "Check In Date"
        Me.CheckIN.Name = "CheckIN"
        '
        'Checkoutdate
        '
        Me.Checkoutdate.HeaderText = "Check Out Date"
        Me.Checkoutdate.Name = "Checkoutdate"
        '
        'RoomService
        '
        Me.RoomService.HeaderText = "Room Service"
        Me.RoomService.Name = "RoomService"
        '
        'KitchenService
        '
        Me.KitchenService.HeaderText = "KitchenSerivce"
        Me.KitchenService.Name = "KitchenService"
        '
        'Label135
        '
        Me.Label135.AutoSize = True
        Me.Label135.Font = New System.Drawing.Font("Copperplate Gothic Light", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label135.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label135.Location = New System.Drawing.Point(25, 22)
        Me.Label135.Name = "Label135"
        Me.Label135.Size = New System.Drawing.Size(227, 16)
        Me.Label135.TabIndex = 48
        Me.Label135.Text = "Current Time Room Status"
        '
        'DataGridView2
        '
        Me.DataGridView2.BackgroundColor = System.Drawing.Color.WhiteSmoke
        Me.DataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView2.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn8, Me.DataGridViewTextBoxColumn9, Me.RoomCheckoutTime, Me.SendRoomService})
        Me.DataGridView2.Location = New System.Drawing.Point(20, 49)
        Me.DataGridView2.Name = "DataGridView2"
        Me.DataGridView2.Size = New System.Drawing.Size(656, 327)
        Me.DataGridView2.TabIndex = 1
        '
        'Label136
        '
        Me.Label136.AutoSize = True
        Me.Label136.Font = New System.Drawing.Font("Copperplate Gothic Light", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label136.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label136.Location = New System.Drawing.Point(17, 21)
        Me.Label136.Name = "Label136"
        Me.Label136.Size = New System.Drawing.Size(129, 16)
        Me.Label136.TabIndex = 49
        Me.Label136.Text = "Room Service :"
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.HeaderText = "Room No"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.HeaderText = "Room Satus"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        '
        'DataGridViewTextBoxColumn8
        '
        Me.DataGridViewTextBoxColumn8.HeaderText = "Check In Date"
        Me.DataGridViewTextBoxColumn8.Name = "DataGridViewTextBoxColumn8"
        '
        'DataGridViewTextBoxColumn9
        '
        Me.DataGridViewTextBoxColumn9.HeaderText = "Check Out Date"
        Me.DataGridViewTextBoxColumn9.Name = "DataGridViewTextBoxColumn9"
        '
        'RoomCheckoutTime
        '
        Me.RoomCheckoutTime.HeaderText = "Check Out Time"
        Me.RoomCheckoutTime.Name = "RoomCheckoutTime"
        '
        'SendRoomService
        '
        Me.SendRoomService.HeaderText = "Send Room Service"
        Me.SendRoomService.Name = "SendRoomService"
        Me.SendRoomService.Text = "Send"
        Me.SendRoomService.UseColumnTextForButtonValue = True
        '
        'RoomSelectForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1013, 747)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.MaterialTabControl1)
        Me.Controls.Add(Me.MaterialTabSelector1)
        Me.Controls.Add(Me.Panel19)
        Me.Name = "RoomSelectForm"
        Me.ShowIcon = False
        Me.Text = "Room  Select Form"
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.FlowLayoutPanel1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        Me.Panel7.ResumeLayout(False)
        Me.Panel7.PerformLayout()
        Me.Panel8.ResumeLayout(False)
        Me.Panel8.PerformLayout()
        Me.Panel9.ResumeLayout(False)
        Me.Panel9.PerformLayout()
        Me.Panel10.ResumeLayout(False)
        Me.Panel10.PerformLayout()
        Me.Panel11.ResumeLayout(False)
        Me.Panel11.PerformLayout()
        Me.Panel12.ResumeLayout(False)
        Me.Panel12.PerformLayout()
        Me.Panel13.ResumeLayout(False)
        Me.Panel13.PerformLayout()
        Me.Panel14.ResumeLayout(False)
        Me.Panel14.PerformLayout()
        Me.Panel15.ResumeLayout(False)
        Me.Panel15.PerformLayout()
        Me.Panel16.ResumeLayout(False)
        Me.Panel16.PerformLayout()
        Me.Panel17.ResumeLayout(False)
        Me.Panel17.PerformLayout()
        Me.Panel18.ResumeLayout(False)
        Me.Panel18.PerformLayout()
        Me.Panel20.ResumeLayout(False)
        Me.Panel20.PerformLayout()
        Me.Panel21.ResumeLayout(False)
        Me.Panel21.PerformLayout()
        Me.Panel22.ResumeLayout(False)
        Me.Panel22.PerformLayout()
        Me.Panel23.ResumeLayout(False)
        Me.Panel23.PerformLayout()
        Me.Panel24.ResumeLayout(False)
        Me.Panel24.PerformLayout()
        Me.Panel25.ResumeLayout(False)
        Me.Panel25.PerformLayout()
        Me.Panel26.ResumeLayout(False)
        Me.Panel26.PerformLayout()
        Me.Panel27.ResumeLayout(False)
        Me.Panel27.PerformLayout()
        Me.Panel28.ResumeLayout(False)
        Me.Panel28.PerformLayout()
        Me.Panel29.ResumeLayout(False)
        Me.Panel29.PerformLayout()
        Me.Panel30.ResumeLayout(False)
        Me.Panel30.PerformLayout()
        Me.Panel31.ResumeLayout(False)
        Me.Panel31.PerformLayout()
        Me.Panel32.ResumeLayout(False)
        Me.Panel32.PerformLayout()
        Me.Panel33.ResumeLayout(False)
        Me.Panel33.PerformLayout()
        Me.MaterialTabControl1.ResumeLayout(False)
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.Panel19.ResumeLayout(False)
        Me.Panel19.PerformLayout()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MaterialTabControl1 As MaterialSkin.Controls.MaterialTabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents MaterialTabSelector1 As MaterialSkin.Controls.MaterialTabSelector
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents Panel19 As Panel
    Friend WithEvents Label2 As Label
    Friend WithEvents MetroDateTime1 As MetroFramework.Controls.MetroDateTime
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents FlowLayoutPanel1 As FlowLayoutPanel
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Button1 As Button
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Button2 As Button
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Button3 As Button
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Button4 As Button
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Panel5 As Panel
    Friend WithEvents Button5 As Button
    Friend WithEvents Label21 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents Panel6 As Panel
    Friend WithEvents Button6 As Button
    Friend WithEvents Label25 As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents Label27 As Label
    Friend WithEvents Label28 As Label
    Friend WithEvents Panel7 As Panel
    Friend WithEvents Button7 As Button
    Friend WithEvents Label29 As Label
    Friend WithEvents Label30 As Label
    Friend WithEvents Label31 As Label
    Friend WithEvents Label32 As Label
    Friend WithEvents Panel8 As Panel
    Friend WithEvents Button8 As Button
    Friend WithEvents Label33 As Label
    Friend WithEvents Label34 As Label
    Friend WithEvents Label35 As Label
    Friend WithEvents Label36 As Label
    Friend WithEvents Panel9 As Panel
    Friend WithEvents Button9 As Button
    Friend WithEvents Label37 As Label
    Friend WithEvents Label38 As Label
    Friend WithEvents Label39 As Label
    Friend WithEvents Label40 As Label
    Friend WithEvents Panel10 As Panel
    Friend WithEvents Button10 As Button
    Friend WithEvents Label41 As Label
    Friend WithEvents Label42 As Label
    Friend WithEvents Label43 As Label
    Friend WithEvents Label44 As Label
    Friend WithEvents Panel11 As Panel
    Friend WithEvents Button11 As Button
    Friend WithEvents Label45 As Label
    Friend WithEvents Label46 As Label
    Friend WithEvents Label47 As Label
    Friend WithEvents Label48 As Label
    Friend WithEvents Panel12 As Panel
    Friend WithEvents Button12 As Button
    Friend WithEvents Label49 As Label
    Friend WithEvents Label50 As Label
    Friend WithEvents Label51 As Label
    Friend WithEvents Label52 As Label
    Friend WithEvents Panel13 As Panel
    Friend WithEvents Button13 As Button
    Friend WithEvents Label53 As Label
    Friend WithEvents Label54 As Label
    Friend WithEvents Label55 As Label
    Friend WithEvents Label56 As Label
    Friend WithEvents Panel14 As Panel
    Friend WithEvents Button14 As Button
    Friend WithEvents Label57 As Label
    Friend WithEvents Label58 As Label
    Friend WithEvents Label59 As Label
    Friend WithEvents Label60 As Label
    Friend WithEvents Panel15 As Panel
    Friend WithEvents Button15 As Button
    Friend WithEvents Label61 As Label
    Friend WithEvents Label62 As Label
    Friend WithEvents Label63 As Label
    Friend WithEvents Label64 As Label
    Friend WithEvents Panel16 As Panel
    Friend WithEvents Button16 As Button
    Friend WithEvents Label65 As Label
    Friend WithEvents Label66 As Label
    Friend WithEvents Label67 As Label
    Friend WithEvents Label68 As Label
    Friend WithEvents Panel17 As Panel
    Friend WithEvents Button17 As Button
    Friend WithEvents Label69 As Label
    Friend WithEvents Label70 As Label
    Friend WithEvents Label71 As Label
    Friend WithEvents Label72 As Label
    Friend WithEvents Panel18 As Panel
    Friend WithEvents Button18 As Button
    Friend WithEvents Label73 As Label
    Friend WithEvents Label74 As Label
    Friend WithEvents Label75 As Label
    Friend WithEvents Label76 As Label
    Friend WithEvents Panel20 As Panel
    Friend WithEvents Button19 As Button
    Friend WithEvents Label77 As Label
    Friend WithEvents Label78 As Label
    Friend WithEvents Label79 As Label
    Friend WithEvents Label80 As Label
    Friend WithEvents Panel21 As Panel
    Friend WithEvents Button20 As Button
    Friend WithEvents Label81 As Label
    Friend WithEvents Label82 As Label
    Friend WithEvents Label83 As Label
    Friend WithEvents Label84 As Label
    Friend WithEvents Panel22 As Panel
    Friend WithEvents Button21 As Button
    Friend WithEvents Label85 As Label
    Friend WithEvents Label86 As Label
    Friend WithEvents Label87 As Label
    Friend WithEvents Label88 As Label
    Friend WithEvents Panel23 As Panel
    Friend WithEvents Button22 As Button
    Friend WithEvents Label89 As Label
    Friend WithEvents Label90 As Label
    Friend WithEvents Label91 As Label
    Friend WithEvents Label92 As Label
    Friend WithEvents Panel24 As Panel
    Friend WithEvents Button23 As Button
    Friend WithEvents Label93 As Label
    Friend WithEvents Label94 As Label
    Friend WithEvents Label95 As Label
    Friend WithEvents Label96 As Label
    Friend WithEvents Panel25 As Panel
    Friend WithEvents Button24 As Button
    Friend WithEvents Label97 As Label
    Friend WithEvents Label98 As Label
    Friend WithEvents Label99 As Label
    Friend WithEvents Label100 As Label
    Friend WithEvents Panel26 As Panel
    Friend WithEvents Button25 As Button
    Friend WithEvents Label101 As Label
    Friend WithEvents Label102 As Label
    Friend WithEvents Label103 As Label
    Friend WithEvents Label104 As Label
    Friend WithEvents Panel27 As Panel
    Friend WithEvents Button26 As Button
    Friend WithEvents Label105 As Label
    Friend WithEvents Label106 As Label
    Friend WithEvents Label107 As Label
    Friend WithEvents Label108 As Label
    Friend WithEvents Panel28 As Panel
    Friend WithEvents Button27 As Button
    Friend WithEvents Label109 As Label
    Friend WithEvents Label110 As Label
    Friend WithEvents Label111 As Label
    Friend WithEvents Label112 As Label
    Friend WithEvents Panel29 As Panel
    Friend WithEvents Button28 As Button
    Friend WithEvents Label113 As Label
    Friend WithEvents Label114 As Label
    Friend WithEvents Label115 As Label
    Friend WithEvents Label116 As Label
    Friend WithEvents Panel30 As Panel
    Friend WithEvents Button29 As Button
    Friend WithEvents Label117 As Label
    Friend WithEvents Label118 As Label
    Friend WithEvents Label119 As Label
    Friend WithEvents Label120 As Label
    Friend WithEvents Panel31 As Panel
    Friend WithEvents Button30 As Button
    Friend WithEvents Label121 As Label
    Friend WithEvents Label122 As Label
    Friend WithEvents Label123 As Label
    Friend WithEvents Label124 As Label
    Friend WithEvents Panel32 As Panel
    Friend WithEvents Button31 As Button
    Friend WithEvents Label125 As Label
    Friend WithEvents Label126 As Label
    Friend WithEvents Label127 As Label
    Friend WithEvents Label128 As Label
    Friend WithEvents Panel33 As Panel
    Friend WithEvents Button32 As Button
    Friend WithEvents Label129 As Label
    Friend WithEvents Label130 As Label
    Friend WithEvents Label131 As Label
    Friend WithEvents Label132 As Label
    Friend WithEvents StatusStrip1 As StatusStrip
    Friend WithEvents ToolStripStatusLabel1 As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel2 As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel3 As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel4 As ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel5 As ToolStripStatusLabel
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents MaterialRaisedButton1 As MaterialSkin.Controls.MaterialRaisedButton
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label133 As Label
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents Label134 As Label
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents roomno As DataGridViewTextBoxColumn
    Friend WithEvents Roomasdfdas As DataGridViewTextBoxColumn
    Friend WithEvents RoomStatusss As DataGridViewTextBoxColumn
    Friend WithEvents Peopleasdf As DataGridViewTextBoxColumn
    Friend WithEvents guestname As DataGridViewTextBoxColumn
    Friend WithEvents contactno As DataGridViewTextBoxColumn
    Friend WithEvents noofpeople As DataGridViewTextBoxColumn
    Friend WithEvents CheckIN As DataGridViewTextBoxColumn
    Friend WithEvents Checkoutdate As DataGridViewTextBoxColumn
    Friend WithEvents RoomService As DataGridViewTextBoxColumn
    Friend WithEvents KitchenService As DataGridViewTextBoxColumn
    Friend WithEvents Label135 As Label
    Friend WithEvents Label136 As Label
    Friend WithEvents DataGridView2 As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn8 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn9 As DataGridViewTextBoxColumn
    Friend WithEvents RoomCheckoutTime As DataGridViewTextBoxColumn
    Friend WithEvents SendRoomService As DataGridViewButtonColumn
End Class
