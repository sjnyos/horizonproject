﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class HouseKeepingAuditForm
    Inherits MetroFramework.Forms.MetroForm


    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.sn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Item = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.unit = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Rate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.oqyt = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ovalue = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Rqtt = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.rvalue = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.cqty = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.cvalue = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Cost = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Damage = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.cosing = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ClosingValue = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Location = New System.Drawing.Point(24, 76)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(803, 59)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.sn, Me.Item, Me.unit, Me.Rate, Me.oqyt, Me.ovalue, Me.Rqtt, Me.rvalue, Me.cqty, Me.cvalue, Me.Cost, Me.Damage, Me.cosing, Me.ClosingValue})
        Me.DataGridView1.Location = New System.Drawing.Point(23, 156)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(803, 394)
        Me.DataGridView1.TabIndex = 1
        '
        'sn
        '
        Me.sn.HeaderText = "S.N"
        Me.sn.Name = "sn"
        '
        'Item
        '
        Me.Item.HeaderText = "Item"
        Me.Item.Name = "Item"
        '
        'unit
        '
        Me.unit.HeaderText = "Unit"
        Me.unit.Name = "unit"
        '
        'Rate
        '
        Me.Rate.HeaderText = "Rate"
        Me.Rate.Name = "Rate"
        '
        'oqyt
        '
        Me.oqyt.HeaderText = "O.Qty"
        Me.oqyt.Name = "oqyt"
        '
        'ovalue
        '
        Me.ovalue.HeaderText = "O.Value"
        Me.ovalue.Name = "ovalue"
        '
        'Rqtt
        '
        Me.Rqtt.HeaderText = "R. Qty"
        Me.Rqtt.Name = "Rqtt"
        '
        'rvalue
        '
        Me.rvalue.HeaderText = "R.Value"
        Me.rvalue.Name = "rvalue"
        '
        'cqty
        '
        Me.cqty.HeaderText = "C.Qty"
        Me.cqty.Name = "cqty"
        '
        'cvalue
        '
        Me.cvalue.HeaderText = "`C.Value"
        Me.cvalue.Name = "cvalue"
        '
        'Cost
        '
        Me.Cost.HeaderText = "Cost"
        Me.Cost.Name = "Cost"
        '
        'Damage
        '
        Me.Damage.HeaderText = "Damaged"
        Me.Damage.Name = "Damage"
        '
        'cosing
        '
        Me.cosing.HeaderText = "Closing"
        Me.cosing.Name = "cosing"
        '
        'ClosingValue
        '
        Me.ClosingValue.HeaderText = "Closing Value"
        Me.ClosingValue.Name = "ClosingValue"
        '
        'GroupBox2
        '
        Me.GroupBox2.Location = New System.Drawing.Point(23, 556)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(803, 59)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        '
        'HouseKeepingAuditForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(850, 630)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "HouseKeepingAuditForm"
        Me.Text = "House Keeping Audit"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents sn As DataGridViewTextBoxColumn
    Friend WithEvents Item As DataGridViewTextBoxColumn
    Friend WithEvents unit As DataGridViewTextBoxColumn
    Friend WithEvents Rate As DataGridViewTextBoxColumn
    Friend WithEvents oqyt As DataGridViewTextBoxColumn
    Friend WithEvents ovalue As DataGridViewTextBoxColumn
    Friend WithEvents Rqtt As DataGridViewTextBoxColumn
    Friend WithEvents rvalue As DataGridViewTextBoxColumn
    Friend WithEvents cqty As DataGridViewTextBoxColumn
    Friend WithEvents cvalue As DataGridViewTextBoxColumn
    Friend WithEvents Cost As DataGridViewTextBoxColumn
    Friend WithEvents Damage As DataGridViewTextBoxColumn
    Friend WithEvents cosing As DataGridViewTextBoxColumn
    Friend WithEvents ClosingValue As DataGridViewTextBoxColumn
    Friend WithEvents GroupBox2 As GroupBox
End Class
